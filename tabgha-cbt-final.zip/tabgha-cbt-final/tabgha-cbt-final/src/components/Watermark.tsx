// src/components/Watermark.tsx
export default function Watermark() {
  return (
    <div
      aria-hidden="true"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 0,
        pointerEvents: "none",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
      }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/logo.png"
        alt=""
        style={{
          width: "520px",
          maxWidth: "60vw",
          opacity: 0.045,
          filter: "grayscale(100%)",
          userSelect: "none",
        } as React.CSSProperties}
      />
    </div>
  );
}
