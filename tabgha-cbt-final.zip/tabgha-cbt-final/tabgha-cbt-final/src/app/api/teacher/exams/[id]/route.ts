// src/app/api/teacher/exams/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  return user?.role === "TEACHER" || user?.role === "ADMIN" ? user : null;
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const { title, subjectId, classRoom, duration } = await req.json();
    const exam = await prisma.exam.update({
      where: { id: Number(id), status: "DRAFT" },
      data: { title, subjectId: Number(subjectId), classRoom, duration: Number(duration) },
      include: { subject: { select: { id: true, name: true } } },
    });
    return NextResponse.json({ success: true, data: { ...exam, createdAt: exam.createdAt.toISOString() } });
  } catch {
    return NextResponse.json({ success: false, error: "Gagal mengupdate ujian" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const examId = Number(id);
    // Delete cheat logs → attempts → exam questions → exam (cascade order)
    const attempts = await prisma.examAttempt.findMany({ where: { examId }, select: { id: true } });
    if (attempts.length > 0) {
      await prisma.cheatLog.deleteMany({ where: { attemptId: { in: attempts.map(a => a.id) } } });
      await prisma.examAttempt.deleteMany({ where: { examId } });
    }
    await prisma.examQuestion.deleteMany({ where: { examId } });
    await prisma.exam.delete({ where: { id: examId } });
    return NextResponse.json({ success: true, message: "Ujian berhasil dihapus" });
  } catch {
    return NextResponse.json({ success: false, error: "Gagal menghapus ujian" }, { status: 500 });
  }
}
