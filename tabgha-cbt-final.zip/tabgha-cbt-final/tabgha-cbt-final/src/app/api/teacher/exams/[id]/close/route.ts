// src/app/api/teacher/exams/[id]/close/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user || (user.role !== "TEACHER" && user.role !== "ADMIN")) {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const examId = Number(id);

  try {
    const exam = await prisma.exam.update({
      where: { id: examId },
      data: { status: "CLOSED" },
    });
    return NextResponse.json({ success: true, data: { status: exam.status } });
  } catch {
    return NextResponse.json({ success: false, error: "Gagal menutup ujian" }, { status: 500 });
  }
}
