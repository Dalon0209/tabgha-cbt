// src/app/api/teacher/exams/[id]/grade/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  return user?.role === "TEACHER" || user?.role === "ADMIN" ? user : null;
}

// GET — load all submitted attempts with essay questions and answers
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;

  const exam = await prisma.exam.findUnique({
    where: { id: Number(id) },
    include: {
      subject: { select: { name: true } },
      examQuestions: {
        include: { question: true },
        orderBy: { order: "asc" },
      },
    },
  });

  if (!exam) return NextResponse.json({ success: false, error: "Ujian tidak ditemukan" }, { status: 404 });

  // Only essay questions
  const essayQuestions = exam.examQuestions
    .filter(eq => eq.question.type === "ESSAY")
    .map(eq => eq.question);

  if (essayQuestions.length === 0) {
    return NextResponse.json({ success: true, data: { exam, essayQuestions: [], attempts: [] } });
  }

  const attempts = await prisma.examAttempt.findMany({
    where: { examId: Number(id), isSubmitted: true },
    include: {
      student: { select: { id: true, name: true, classRoom: true } },
      cheatLogs: { select: { id: true } },
    },
    orderBy: { submittedAt: "asc" },
  });

  return NextResponse.json({
    success: true,
    data: {
      exam: { id: exam.id, title: exam.title, subject: exam.subject, classRoom: exam.classRoom },
      essayQuestions,
      attempts: attempts.map(a => ({
        id: a.id,
        student: a.student,
        answers: a.answers,
        score: a.score,
        essayScore: a.essayScore,
        maxScore: a.maxScore,
        isValid: a.isValid,
        cheatCount: a.cheatLogs.length,
        submittedAt: a.submittedAt?.toISOString() ?? null,
        isGraded: a.essayScore !== null,
      })),
    },
  });
}

// POST — save essay score for one attempt and recalculate total score
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const { attemptId, essayScore } = await req.json();

  if (typeof essayScore !== "number" || essayScore < 0 || essayScore > 100) {
    return NextResponse.json({ success: false, error: "Nilai essay tidak valid (0-100)" }, { status: 400 });
  }

  // Load attempt with exam questions to recalculate total
  const attempt = await prisma.examAttempt.findUnique({
    where: { id: Number(attemptId) },
    include: {
      exam: {
        include: {
          examQuestions: { include: { question: true } },
        },
      },
    },
  });

  if (!attempt) return NextResponse.json({ success: false, error: "Attempt tidak ditemukan" }, { status: 404 });

  const answers = attempt.answers as Record<string, string>;

  // Recalculate: MC auto-score + essay manual score
  let mcScore = 0;
  let mcMax = 0;
  let essayMax = 0;

  for (const eq of attempt.exam.examQuestions) {
    const q = eq.question;
    if (q.type === "MULTIPLE_CHOICE") {
      mcMax += q.points;
      if (q.correctOpt && answers[String(q.id)] === q.correctOpt) {
        mcScore += q.points;
      }
    } else {
      essayMax += q.points;
    }
  }

  const totalMax = mcMax + essayMax;

  // Essay score is given as 0-100 percentage, convert to actual points
  const essayPoints = essayMax > 0 ? (essayScore / 100) * essayMax : 0;
  const totalPoints = mcScore + essayPoints;
  const finalScore = totalMax > 0 ? (totalPoints / totalMax) * 100 : 0;

  await prisma.examAttempt.update({
    where: { id: Number(attemptId) },
    data: {
      essayScore,           // store the essay percentage given by teacher
      score: finalScore,    // update the combined final score
      maxScore: 100,
    },
  });

  return NextResponse.json({
    success: true,
    data: { attemptId, essayScore, finalScore: Math.round(finalScore * 10) / 10 },
  });
}
