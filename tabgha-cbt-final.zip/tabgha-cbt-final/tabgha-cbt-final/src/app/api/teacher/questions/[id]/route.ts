// src/app/api/teacher/questions/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  return user?.role === "TEACHER" || user?.role === "ADMIN" ? user : null;
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const { subjectId, type, body, imageUrl, videoUrl, optionA, optionB, optionC, optionD, correctOpt, points } = await req.json();
  const q = await prisma.question.update({
    where: { id: Number(id) },
    data: { subjectId: Number(subjectId), type, body, imageUrl: imageUrl || null, videoUrl: videoUrl || null, optionA: optionA || null, optionB: optionB || null, optionC: optionC || null, optionD: optionD || null, correctOpt: correctOpt || null, points: Number(points) || 1 },
  });
  return NextResponse.json({ success: true, data: q });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const questionId = Number(id);
    // Remove from any exams first, then delete the question
    await prisma.examQuestion.deleteMany({ where: { questionId } });
    await prisma.question.delete({ where: { id: questionId } });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ success: false, error: "Gagal menghapus soal" }, { status: 500 });
  }
}
