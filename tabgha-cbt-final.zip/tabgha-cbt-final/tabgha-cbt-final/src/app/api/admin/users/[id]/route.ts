// src/app/api/admin/users/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest, hashPassword } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  return user?.role === "ADMIN";
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;

  try {
    const { username, password, name, role, classRoom } = await req.json();
    const data: Record<string, unknown> = { username, name, role, classRoom: classRoom || null };
    if (password) data.password = await hashPassword(password);

    const user = await prisma.user.update({
      where: { id: Number(id) },
      data,
      select: { id: true, username: true, name: true, role: true, classRoom: true, createdAt: true },
    });
    return NextResponse.json({ success: true, data: { ...user, createdAt: user.createdAt.toISOString() } });
  } catch {
    return NextResponse.json({ success: false, error: "Gagal update" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const userId = Number(id);
    // Delete student's cheat logs and attempts first
    const attempts = await prisma.examAttempt.findMany({ where: { studentId: userId }, select: { id: true } });
    if (attempts.length > 0) {
      await prisma.cheatLog.deleteMany({ where: { attemptId: { in: attempts.map(a => a.id) } } });
      await prisma.examAttempt.deleteMany({ where: { studentId: userId } });
    }
    await prisma.user.delete({ where: { id: userId } });
    return NextResponse.json({ success: true, message: "Pengguna berhasil dihapus" });
  } catch {
    return NextResponse.json({ success: false, error: "Gagal menghapus pengguna" }, { status: 500 });
  }
}
