// src/app/teacher/grade/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import GradeClient from "./GradeClient";

export default async function GradePage() {
  const user = await getCurrentUser();

  // Get all published/closed exams that have essay questions
  const exams = await prisma.exam.findMany({
    where: {
      creatorId: user!.userId,
      status: { in: ["PUBLISHED", "CLOSED"] },
      examQuestions: {
        some: { question: { type: "ESSAY" } },
      },
    },
    include: {
      subject: { select: { name: true } },
      _count: { select: { examAttempts: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Koreksi Essay</h1>
        <p className="text-gray-500 mt-1">
          Periksa dan beri nilai jawaban essay siswa. Nilai akhir dihitung otomatis setelah essay dinilai.
        </p>
      </div>
      <GradeClient
        exams={exams.map(e => ({
          id: e.id,
          title: e.title,
          subject: e.subject,
          classRoom: e.classRoom,
          status: e.status,
          _count: e._count,
        }))}
      />
    </div>
  );
}
