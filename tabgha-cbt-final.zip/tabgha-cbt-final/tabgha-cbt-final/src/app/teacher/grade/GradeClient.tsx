"use client";
// src/app/teacher/grade/GradeClient.tsx
import { useState } from "react";

interface ExamSummary {
  id: number;
  title: string;
  classRoom: string;
  status: string;
  subject: { name: string };
  _count: { examAttempts: number };
}

interface EssayQuestion {
  id: number;
  body: string;
  points: number;
  imageUrl?: string | null;
}

interface AttemptRow {
  id: number;
  student: { id: number; name: string; classRoom: string | null };
  answers: Record<string, string>;
  score: number | null;
  essayScore: number | null;
  isValid: boolean;
  cheatCount: number;
  submittedAt: string | null;
  isGraded: boolean;
}

export default function GradeClient({ exams }: { exams: ExamSummary[] }) {
  const [selectedExam, setSelectedExam] = useState<ExamSummary | null>(null);
  const [essayQuestions, setEssayQuestions] = useState<EssayQuestion[]>([]);
  const [attempts, setAttempts] = useState<AttemptRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState<number | null>(null); // attemptId being saved
  const [scores, setScores] = useState<Record<number, string>>({}); // attemptId → score string
  const [saved, setSaved] = useState<Record<number, boolean>>({});
  const [activeAttempt, setActiveAttempt] = useState<AttemptRow | null>(null);
  const [filterStatus, setFilterStatus] = useState<"ALL" | "GRADED" | "UNGRADED">("ALL");

  async function loadExam(exam: ExamSummary) {
    setSelectedExam(exam);
    setActiveAttempt(null);
    setLoading(true);
    setScores({});
    setSaved({});

    const res = await fetch(`/api/teacher/exams/${exam.id}/grade`);
    const data = await res.json();

    if (data.success) {
      setEssayQuestions(data.data.essayQuestions);
      setAttempts(data.data.attempts);
      // Pre-fill scores from existing essay scores
      const existing: Record<number, string> = {};
      data.data.attempts.forEach((a: AttemptRow) => {
        if (a.essayScore !== null) existing[a.id] = String(a.essayScore);
      });
      setScores(existing);
    }
    setLoading(false);
  }

  async function saveScore(attemptId: number) {
    const scoreVal = Number(scores[attemptId]);
    if (isNaN(scoreVal) || scoreVal < 0 || scoreVal > 100) {
      alert("Nilai harus antara 0 dan 100");
      return;
    }
    setSaving(attemptId);
    const res = await fetch(`/api/teacher/exams/${selectedExam!.id}/grade`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ attemptId, essayScore: scoreVal }),
    });
    const data = await res.json();
    if (data.success) {
      setSaved(p => ({ ...p, [attemptId]: true }));
      // Update local attempt data
      setAttempts(p => p.map(a => a.id === attemptId
        ? { ...a, essayScore: scoreVal, score: data.data.finalScore, isGraded: true }
        : a
      ));
      if (activeAttempt?.id === attemptId) {
        setActiveAttempt(p => p ? { ...p, essayScore: scoreVal, score: data.data.finalScore, isGraded: true } : p);
      }
    } else {
      alert(data.error || "Gagal menyimpan nilai");
    }
    setSaving(null);
  }

  const filteredAttempts = attempts.filter(a => {
    if (filterStatus === "GRADED") return a.isGraded;
    if (filterStatus === "UNGRADED") return !a.isGraded;
    return true;
  });

  const gradedCount = attempts.filter(a => a.isGraded).length;
  const ungradedCount = attempts.length - gradedCount;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: "24px" }}>

      {/* ── Left: Exam list ── */}
      <div>
        <div className="card" style={{ padding: "16px" }}>
          <h2 style={{ fontWeight: 700, fontSize: "0.9rem", marginBottom: "12px", color: "#0f172a" }}>
            Pilih Ujian
          </h2>
          {exams.length === 0 && (
            <p style={{ fontSize: "0.875rem", color: "#94a3b8", textAlign: "center", padding: "24px 0" }}>
              Tidak ada ujian dengan soal essay
            </p>
          )}
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {exams.map(e => (
              <button
                key={e.id}
                onClick={() => loadExam(e)}
                style={{
                  textAlign: "left", padding: "12px", borderRadius: "10px", cursor: "pointer",
                  border: `2px solid ${selectedExam?.id === e.id ? "#2563eb" : "#f1f5f9"}`,
                  background: selectedExam?.id === e.id ? "#eff6ff" : "white",
                  transition: "all 0.15s",
                }}
              >
                <div style={{ fontWeight: 600, fontSize: "0.875rem", color: "#0f172a", marginBottom: "4px" }}>
                  {e.title}
                </div>
                <div style={{ fontSize: "0.75rem", color: "#64748b" }}>
                  {e.subject.name} · Kelas {e.classRoom}
                </div>
                <div style={{ fontSize: "0.75rem", color: "#94a3b8", marginTop: "2px" }}>
                  {e._count.examAttempts} peserta
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Right: Grading area ── */}
      <div>
        {!selectedExam && (
          <div className="card" style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "300px" }}>
            <div style={{ textAlign: "center", color: "#94a3b8" }}>
              <div style={{ fontSize: "3rem", marginBottom: "12px" }}>📝</div>
              <p>Pilih ujian untuk mulai mengoreksi essay</p>
            </div>
          </div>
        )}

        {selectedExam && loading && (
          <div className="card" style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "200px" }}>
            <p style={{ color: "#94a3b8" }}>Memuat data...</p>
          </div>
        )}

        {selectedExam && !loading && (
          <>
            {/* Stats bar */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px", marginBottom: "16px" }}>
              <div className="stat-card">
                <div className="stat-value" style={{ color: "#2563eb" }}>{attempts.length}</div>
                <div className="stat-label">Total Peserta</div>
              </div>
              <div className="stat-card">
                <div className="stat-value" style={{ color: "#16a34a" }}>{gradedCount}</div>
                <div className="stat-label">Sudah Dinilai</div>
              </div>
              <div className="stat-card">
                <div className="stat-value" style={{ color: "#d97706" }}>{ungradedCount}</div>
                <div className="stat-label">Belum Dinilai</div>
              </div>
            </div>

            {/* Essay questions reference */}
            <div className="card" style={{ marginBottom: "16px" }}>
              <h3 style={{ fontWeight: 700, fontSize: "0.9rem", marginBottom: "10px" }}>
                📋 Soal Essay ({essayQuestions.length} soal)
              </h3>
              {essayQuestions.map((q, i) => (
                <div key={q.id} style={{ padding: "10px 12px", background: "#f8fafc", borderRadius: "8px", marginBottom: "8px", borderLeft: "3px solid #2563eb" }}>
                  <div style={{ fontSize: "0.75rem", color: "#2563eb", fontWeight: 600, marginBottom: "4px" }}>
                    Soal Essay #{i + 1} · {q.points} poin
                  </div>
                  <p style={{ fontSize: "0.875rem", color: "#0f172a", margin: 0 }}>{q.body}</p>
                </div>
              ))}
            </div>

            {/* Filter tabs */}
            <div style={{ display: "flex", gap: "8px", marginBottom: "12px" }}>
              {(["ALL", "UNGRADED", "GRADED"] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setFilterStatus(f)}
                  className={filterStatus === f ? "btn btn-primary btn-sm" : "btn btn-ghost btn-sm"}
                >
                  {f === "ALL" ? `Semua (${attempts.length})` : f === "UNGRADED" ? `Belum Dinilai (${ungradedCount})` : `Sudah Dinilai (${gradedCount})`}
                </button>
              ))}
            </div>

            {/* Attempts table */}
            <div className="table-wrapper" style={{ marginBottom: "16px" }}>
              <table>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nama Siswa</th>
                    <th>Kelas</th>
                    <th>Nilai PG</th>
                    <th>Nilai Essay (0–100)</th>
                    <th>Nilai Akhir</th>
                    <th>Kecurangan</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAttempts.length === 0 && (
                    <tr>
                      <td colSpan={8} style={{ textAlign: "center", color: "#94a3b8", padding: "32px" }}>
                        Belum ada peserta yang submit
                      </td>
                    </tr>
                  )}
                  {filteredAttempts.map((attempt, i) => (
                    <tr key={attempt.id} style={{ background: activeAttempt?.id === attempt.id ? "#f0f9ff" : undefined }}>
                      <td style={{ color: "#94a3b8", fontSize: "0.75rem" }}>{i + 1}</td>
                      <td>
                        <div style={{ fontWeight: 600 }}>{attempt.student.name}</div>
                        {!attempt.isGraded && (
                          <span className="badge badge-yellow" style={{ fontSize: "0.65rem", marginTop: "2px" }}>Belum dinilai</span>
                        )}
                        {attempt.isGraded && (
                          <span className="badge badge-green" style={{ fontSize: "0.65rem", marginTop: "2px" }}>✓ Sudah dinilai</span>
                        )}
                      </td>
                      <td>{attempt.student.classRoom}</td>
                      <td style={{ fontFamily: "monospace", fontSize: "0.875rem" }}>
                        {/* MC-only score before essay grading */}
                        {attempt.isGraded
                          ? <span style={{ color: "#94a3b8", fontSize: "0.75rem" }}>sudah digabung</span>
                          : <span style={{ color: "#64748b" }}>–</span>}
                      </td>
                      <td>
                        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                          <input
                            type="number"
                            min={0}
                            max={100}
                            placeholder="0–100"
                            value={scores[attempt.id] ?? ""}
                            onChange={e => {
                              setScores(p => ({ ...p, [attempt.id]: e.target.value }));
                              setSaved(p => ({ ...p, [attempt.id]: false }));
                            }}
                            style={{
                              width: "72px", padding: "6px 8px",
                              border: `1.5px solid ${saved[attempt.id] ? "#16a34a" : "#e2e8f0"}`,
                              borderRadius: "8px", fontSize: "0.875rem",
                              fontFamily: "monospace", textAlign: "center",
                              outline: "none",
                            }}
                          />
                          {saved[attempt.id] && <span style={{ color: "#16a34a", fontSize: "1rem" }}>✓</span>}
                        </div>
                      </td>
                      <td>
                        <span style={{
                          fontWeight: 700, fontSize: "0.9rem",
                          color: (attempt.score ?? 0) >= 75 ? "#16a34a" : (attempt.score !== null ? "#dc2626" : "#94a3b8"),
                        }}>
                          {attempt.score !== null ? attempt.score.toFixed(1) : "–"}
                        </span>
                      </td>
                      <td>
                        {attempt.cheatCount > 0
                          ? <span className="badge badge-red">⚠️ {attempt.cheatCount}</span>
                          : <span className="badge badge-green">Bersih</span>}
                      </td>
                      <td>
                        <div style={{ display: "flex", gap: "6px" }}>
                          <button
                            className="btn btn-outline btn-sm"
                            onClick={() => setActiveAttempt(activeAttempt?.id === attempt.id ? null : attempt)}
                          >
                            {activeAttempt?.id === attempt.id ? "Tutup" : "👁 Lihat"}
                          </button>
                          <button
                            className="btn btn-primary btn-sm"
                            onClick={() => saveScore(attempt.id)}
                            disabled={saving === attempt.id || scores[attempt.id] === undefined || scores[attempt.id] === ""}
                          >
                            {saving === attempt.id ? "..." : "Simpan"}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* ── Essay answer viewer ── */}
            {activeAttempt && (
              <div className="card" style={{ borderLeft: "4px solid #2563eb" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                  <div>
                    <h3 style={{ fontWeight: 700, fontSize: "1rem", margin: 0 }}>
                      Jawaban Essay — {activeAttempt.student.name}
                    </h3>
                    <p style={{ fontSize: "0.8rem", color: "#64748b", margin: "4px 0 0" }}>
                      Kelas {activeAttempt.student.classRoom} · Submit: {activeAttempt.submittedAt
                        ? new Date(activeAttempt.submittedAt).toLocaleString("id-ID")
                        : "–"}
                      {activeAttempt.cheatCount > 0 && (
                        <span style={{ color: "#dc2626", marginLeft: "8px" }}>⚠️ {activeAttempt.cheatCount} pelanggaran</span>
                      )}
                    </p>
                  </div>
                  <button className="btn btn-ghost btn-sm" onClick={() => setActiveAttempt(null)}>✕ Tutup</button>
                </div>

                {essayQuestions.map((q, i) => {
                  const studentAnswer = (activeAttempt.answers as Record<string, string>)[String(q.id)];
                  return (
                    <div key={q.id} style={{ marginBottom: "24px" }}>
                      {/* Question */}
                      <div style={{ background: "#eff6ff", borderRadius: "10px", padding: "12px 16px", marginBottom: "10px" }}>
                        <div style={{ fontSize: "0.75rem", color: "#2563eb", fontWeight: 700, marginBottom: "4px" }}>
                          Soal Essay #{i + 1} · {q.points} poin
                        </div>
                        <p style={{ margin: 0, fontSize: "0.9rem", color: "#0f172a" }}>{q.body}</p>
                      </div>

                      {/* Student answer */}
                      <div style={{ background: "#f8fafc", borderRadius: "10px", padding: "14px 16px", border: "1px solid #e2e8f0", minHeight: "80px" }}>
                        <div style={{ fontSize: "0.7rem", color: "#94a3b8", fontWeight: 600, marginBottom: "6px", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                          Jawaban Siswa
                        </div>
                        {studentAnswer
                          ? <p style={{ margin: 0, fontSize: "0.9rem", color: "#0f172a", lineHeight: 1.6, whiteSpace: "pre-wrap" }}>{studentAnswer}</p>
                          : <p style={{ margin: 0, fontSize: "0.875rem", color: "#94a3b8", fontStyle: "italic" }}>Tidak dijawab</p>}
                      </div>
                    </div>
                  );
                })}

                {/* Score input at bottom of viewer */}
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: "16px", display: "flex", alignItems: "center", gap: "16px" }}>
                  <div>
                    <label style={{ fontSize: "0.8rem", fontWeight: 600, color: "#0f172a", display: "block", marginBottom: "6px" }}>
                      Nilai Essay (0 – 100)
                    </label>
                    <input
                      type="number" min={0} max={100}
                      placeholder="Masukkan nilai..."
                      value={scores[activeAttempt.id] ?? ""}
                      onChange={e => {
                        setScores(p => ({ ...p, [activeAttempt.id]: e.target.value }));
                        setSaved(p => ({ ...p, [activeAttempt.id]: false }));
                      }}
                      style={{
                        width: "140px", padding: "8px 12px",
                        border: "1.5px solid #e2e8f0", borderRadius: "8px",
                        fontSize: "1rem", fontFamily: "monospace", textAlign: "center",
                      }}
                    />
                  </div>
                  <div style={{ marginTop: "20px" }}>
                    <button
                      className="btn btn-primary"
                      onClick={() => saveScore(activeAttempt.id)}
                      disabled={saving === activeAttempt.id || !scores[activeAttempt.id]}
                    >
                      {saving === activeAttempt.id ? "Menyimpan..." : "💾 Simpan Nilai"}
                    </button>
                  </div>
                  {saved[activeAttempt.id] && (
                    <div style={{ marginTop: "20px" }}>
                      <span className="badge badge-green">✓ Tersimpan · Nilai Akhir: {activeAttempt.score?.toFixed(1)}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
