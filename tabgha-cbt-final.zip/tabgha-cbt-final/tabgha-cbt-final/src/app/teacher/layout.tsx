// src/app/teacher/layout.tsx
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import TeacherSidebar from "@/components/teacher/TeacherSidebar";
import Watermark from "@/components/Watermark";

export default async function TeacherLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user || (user.role !== "TEACHER" && user.role !== "ADMIN")) redirect("/login");

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden" style={{ position: "relative" }}>
      <Watermark />
      <TeacherSidebar user={user} />
      <main className="flex-1 overflow-y-auto" style={{ position: "relative", zIndex: 1 }}>
        <div className="page-enter">{children}</div>
      </main>
    </div>
  );
}
