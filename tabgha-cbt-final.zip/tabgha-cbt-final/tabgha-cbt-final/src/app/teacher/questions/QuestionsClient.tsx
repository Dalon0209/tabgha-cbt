"use client";
// src/app/teacher/questions/QuestionsClient.tsx
import { useState } from "react";
import type { Question, Subject } from "@/types";

const defaultForm = {
  subjectId: "", type: "MULTIPLE_CHOICE", body: "", imageUrl: "", videoUrl: "",
  optionA: "", optionB: "", optionC: "", optionD: "", correctOpt: "A", points: 1,
};

export default function QuestionsClient({
  initialQuestions, subjects,
}: { initialQuestions: Question[]; subjects: Subject[] }) {
  const [questions, setQuestions] = useState(initialQuestions);
  const [showModal, setShowModal] = useState(false);
  const [editQ, setEditQ] = useState<Question | null>(null);
  const [form, setForm] = useState({ ...defaultForm });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [filterSubject, setFilterSubject] = useState("ALL");
  const [filterType, setFilterType] = useState("ALL");

  const filtered = questions.filter(q => {
    const ms = filterSubject === "ALL" || String(q.subjectId) === filterSubject;
    const mt = filterType === "ALL" || q.type === filterType;
    return ms && mt;
  });

  function openAdd() {
    setEditQ(null);
    setForm({ ...defaultForm, subjectId: subjects[0]?.id?.toString() || "" });
    setError("");
    setShowModal(true);
  }

  function openEdit(q: Question) {
    setEditQ(q);
    setForm({
      subjectId: String(q.subjectId), type: q.type, body: q.body,
      imageUrl: q.imageUrl || "", videoUrl: q.videoUrl || "",
      optionA: q.optionA || "", optionB: q.optionB || "",
      optionC: q.optionC || "", optionD: q.optionD || "",
      correctOpt: q.correctOpt || "A", points: q.points,
    });
    setError("");
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const payload = { ...form, subjectId: Number(form.subjectId), points: Number(form.points) };
    try {
      const url = editQ ? `/api/teacher/questions/${editQ.id}` : "/api/teacher/questions";
      const method = editQ ? "PUT" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!data.success) { setError(data.error || "Gagal"); return; }
      const saved = { ...data.data, subject: subjects.find(s => s.id === data.data.subjectId) };
      if (editQ) setQuestions(p => p.map(q => q.id === saved.id ? saved : q));
      else setQuestions(p => [saved, ...p]);
      setShowModal(false);
    } catch { setError("Server error"); }
    finally { setLoading(false); }
  }

  async function handleDelete(id: number) {
    if (!confirm("Hapus soal ini?")) return;
    try {
      const res = await fetch(`/api/teacher/questions/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) setQuestions(p => p.filter(q => q.id !== id));
      else alert("Gagal menghapus soal");
    } catch { alert("Server error"); }
  }

  return (
    <>
      {/* Filters + Add */}
      <div className="flex flex-wrap items-center gap-3 mb-5">
        <select className="input w-44" value={filterSubject} onChange={e => setFilterSubject(e.target.value)}>
          <option value="ALL">Semua Mapel</option>
          {subjects.map(s => <option key={s.id} value={String(s.id)}>{s.name}</option>)}
        </select>
        <select className="input w-44" value={filterType} onChange={e => setFilterType(e.target.value)}>
          <option value="ALL">Semua Tipe</option>
          <option value="MULTIPLE_CHOICE">Pilihan Ganda</option>
          <option value="ESSAY">Essay</option>
        </select>
        <span className="text-sm text-gray-400">{filtered.length} soal</span>
        <button className="btn btn-primary btn-sm ml-auto" onClick={openAdd}>+ Tambah Soal</button>
      </div>

      {/* Table */}
      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>#</th><th>Mapel</th><th>Tipe</th><th>Soal</th>
              <th>Poin</th><th>Media</th><th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="text-center text-gray-400 py-10">Belum ada soal</td>
              </tr>
            )}
            {filtered.map((q, i) => (
              <tr key={q.id}>
                <td className="text-gray-400 text-xs">{i + 1}</td>
                <td><span className="badge badge-blue">{q.subject?.name || "–"}</span></td>
                <td>
                  <span className={`badge ${q.type === "MULTIPLE_CHOICE" ? "badge-purple" : "badge-yellow"}`}>
                    {q.type === "MULTIPLE_CHOICE" ? "PG" : "Essay"}
                  </span>
                </td>
                <td className="max-w-xs"><p className="truncate text-sm">{q.body}</p></td>
                <td className="font-mono text-sm">{q.points}</td>
                <td>
                  {(q.imageUrl || q.videoUrl)
                    ? <span className="badge badge-green">{q.imageUrl ? "🖼️" : ""}{q.videoUrl ? "🎬" : ""}</span>
                    : <span className="text-gray-300">–</span>}
                </td>
                <td>
                  <div className="flex gap-1">
                    <button className="btn btn-ghost btn-sm" onClick={() => openEdit(q)}>✏️</button>
                    <button className="btn btn-ghost btn-sm text-red-500" onClick={() => handleDelete(q.id)}>🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ── Modal - Full scroll fix ── */}
      {showModal && (
        <div
          style={{
            position: "fixed", inset: 0, zIndex: 9999,
            backgroundColor: "rgba(0,0,0,0.5)",
            overflowY: "auto",
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "center",
            padding: "24px 16px",
          }}
          onClick={e => { if (e.target === e.currentTarget) setShowModal(false); }}
        >
          <div
            style={{
              backgroundColor: "white",
              borderRadius: "16px",
              width: "100%",
              maxWidth: "660px",
              boxShadow: "0 25px 50px rgba(0,0,0,0.2)",
              margin: "auto",
            }}
          >
            {/* Header */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "20px 24px", borderBottom: "1px solid #f1f5f9" }}>
              <h3 style={{ fontWeight: 700, fontSize: "1.1rem", margin: 0 }}>
                {editQ ? "Edit Soal" : "Tambah Soal Baru"}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                style={{ background: "none", border: "none", fontSize: "1.25rem", cursor: "pointer", color: "#94a3b8", padding: "4px 8px", borderRadius: "8px" }}
              >✕</button>
            </div>

            {/* Body */}
            <div style={{ padding: "24px" }}>
              {error && <div className="alert alert-error" style={{ marginBottom: "16px" }}>{error}</div>}

              <form onSubmit={handleSubmit} id="q-form">
                {/* Subject + Type */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "16px" }}>
                  <div>
                    <label className="label">Mata Pelajaran</label>
                    <select className="input" value={form.subjectId} onChange={e => setForm(p => ({ ...p, subjectId: e.target.value }))}>
                      {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="label">Tipe Soal</label>
                    <select className="input" value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))}>
                      <option value="MULTIPLE_CHOICE">Pilihan Ganda</option>
                      <option value="ESSAY">Essay</option>
                    </select>
                  </div>
                </div>

                {/* Body */}
                <div style={{ marginBottom: "16px" }}>
                  <label className="label">Pertanyaan / Soal</label>
                  <textarea
                    className="input"
                    style={{ minHeight: "96px", resize: "vertical" }}
                    placeholder="Tulis soal di sini..."
                    value={form.body}
                    onChange={e => setForm(p => ({ ...p, body: e.target.value }))}
                    required
                  />
                </div>

                {/* Multimedia */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "16px" }}>
                  <div>
                    <label className="label">URL Gambar (opsional)</label>
                    <input className="input" placeholder="https://..." value={form.imageUrl}
                      onChange={e => setForm(p => ({ ...p, imageUrl: e.target.value }))} />
                    {form.imageUrl && (
                      <div style={{ marginTop: "8px", borderRadius: "8px", overflow: "hidden", border: "1px solid #e2e8f0", background: "#f8fafc" }}>
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={form.imageUrl}
                          alt="Preview gambar"
                          style={{ width: "100%", maxHeight: "120px", objectFit: "contain" }}
                          onError={e => { (e.target as HTMLImageElement).style.display = "none"; (e.target as HTMLImageElement).nextElementSibling?.setAttribute("style", "display:block"); }}
                        />
                        <p style={{ display: "none", padding: "8px", color: "#dc2626", fontSize: "0.75rem" }}>⚠️ Gambar tidak dapat dimuat. Pastikan URL benar dan dapat diakses publik.</p>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="label">URL Video (opsional)</label>
                    <input className="input" placeholder="https://youtube.com/..." value={form.videoUrl}
                      onChange={e => setForm(p => ({ ...p, videoUrl: e.target.value }))} />
                  </div>
                </div>

                {/* Multiple choice */}
                {form.type === "MULTIPLE_CHOICE" && (
                  <div style={{ background: "#eff6ff", borderRadius: "12px", padding: "16px", marginBottom: "16px" }}>
                    <p style={{ fontWeight: 600, color: "#1e40af", fontSize: "0.875rem", marginBottom: "12px" }}>Pilihan Jawaban</p>
                    {(["A", "B", "C", "D"] as const).map(opt => (
                      <div key={opt} style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                        <label style={{ display: "flex", alignItems: "center", gap: "6px", cursor: "pointer", flexShrink: 0 }}>
                          <input
                            type="radio" name="correctOpt" value={opt}
                            checked={form.correctOpt === opt}
                            onChange={() => setForm(p => ({ ...p, correctOpt: opt }))}
                          />
                          <span style={{ fontWeight: 700, color: "#1d4ed8", width: "20px" }}>{opt}.</span>
                        </label>
                        <input
                          className="input"
                          style={{ flex: 1 }}
                          placeholder={`Pilihan ${opt}`}
                          value={form[`option${opt}` as "optionA"]}
                          onChange={e => setForm(p => ({ ...p, [`option${opt}`]: e.target.value }))}
                          required
                        />
                      </div>
                    ))}
                    <p style={{ fontSize: "0.75rem", color: "#2563eb", marginTop: "8px" }}>● = Jawaban benar</p>
                  </div>
                )}

                {/* Points */}
                <div>
                  <label className="label">Poin</label>
                  <input
                    className="input"
                    style={{ width: "100px" }}
                    type="number" min={1} max={100}
                    value={form.points}
                    onChange={e => setForm(p => ({ ...p, points: Number(e.target.value) }))}
                  />
                </div>
              </form>
            </div>

            {/* Footer */}
            <div style={{ display: "flex", gap: "12px", padding: "16px 24px", borderTop: "1px solid #f1f5f9" }}>
              <button type="button" className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setShowModal(false)}>
                Batal
              </button>
              <button type="submit" form="q-form" className="btn btn-primary" style={{ flex: 1 }} disabled={loading}>
                {loading ? "Menyimpan..." : "Simpan Soal"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
