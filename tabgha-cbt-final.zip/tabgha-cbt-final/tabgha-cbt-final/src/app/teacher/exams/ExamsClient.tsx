"use client";
// src/app/teacher/exams/ExamsClient.tsx
import { useState } from "react";
import type { Exam, Subject, Question } from "@/types";

const defaultForm = { title: "", subjectId: "", classRoom: "", duration: 60 };

export default function ExamsClient({
  subjects, initialExams,
}: { subjects: Subject[]; initialExams: Exam[]; teacherId: number }) {
  const [exams, setExams] = useState(initialExams);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [editExam, setEditExam] = useState<Exam | null>(null);
  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  const [form, setForm] = useState({ ...defaultForm });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Question picker state
  const [availableQuestions, setAvailableQuestions] = useState<Question[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  // ── Open create modal ──
  function openCreate() {
    setEditExam(null);
    setForm({ ...defaultForm, subjectId: subjects[0]?.id?.toString() || "" });
    setError("");
    setShowCreateModal(true);
  }

  // ── Open edit modal ──
  function openEdit(exam: Exam) {
    setEditExam(exam);
    setForm({
      title: exam.title,
      subjectId: String(exam.subjectId),
      classRoom: exam.classRoom,
      duration: exam.duration,
    });
    setError("");
    setShowCreateModal(true);
  }

  // ── Save (create or edit) ──
  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const payload = { ...form, subjectId: Number(form.subjectId), duration: Number(form.duration) };

      if (editExam) {
        // Edit existing
        const res = await fetch(`/api/teacher/exams/${editExam.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!data.success) { setError(data.error || "Gagal"); return; }
        setExams(p => p.map(e => e.id === editExam.id ? { ...e, ...data.data } : e));
      } else {
        // Create new
        const res = await fetch("/api/teacher/exams", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!data.success) { setError(data.error || "Gagal"); return; }
        setExams(p => [{ ...data.data, _count: { examQuestions: 0, examAttempts: 0 } }, ...p]);
      }
      setShowCreateModal(false);
      setForm({ ...defaultForm });
    } catch { setError("Server error"); }
    finally { setLoading(false); }
  }

  // ── Question picker ──
  async function openQuestionPicker(exam: Exam) {
    setActiveExam(exam);
    const [qRes, selectedRes] = await Promise.all([
      fetch(`/api/teacher/questions?subjectId=${exam.subjectId}`),
      fetch(`/api/teacher/exams/${exam.id}/questions`),
    ]);
    const qData = await qRes.json();
    const selData = await selectedRes.json();
    setAvailableQuestions(qData.data || []);
    setSelectedIds(new Set((selData.data || []).map((q: Question) => q.id)));
    setShowQuestionModal(true);
  }

  async function saveQuestions() {
    if (!activeExam) return;
    setLoading(true);
    await fetch(`/api/teacher/exams/${activeExam.id}/questions`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questionIds: Array.from(selectedIds) }),
    });
    setExams(p => p.map(e => e.id === activeExam.id
      ? { ...e, _count: { ...e._count!, examQuestions: selectedIds.size } }
      : e
    ));
    setShowQuestionModal(false);
    setLoading(false);
  }

  // ── Publish ──
  async function handlePublish(examId: number) {
    if (!confirm("Publikasikan ujian ini? Siswa akan bisa mengaksesnya dengan token.")) return;
    const res = await fetch(`/api/teacher/exams/${examId}/publish`, { method: "POST" });
    const data = await res.json();
    if (data.success) {
      setExams(p => p.map(e => e.id === examId ? { ...e, status: "PUBLISHED", token: data.data.token } : e));
    } else {
      alert(data.error || "Gagal mempublikasikan");
    }
  }

  // ── Close Exam ──
  async function handleClose(examId: number) {
    if (!confirm("Tutup ujian ini? Siswa tidak dapat lagi mengakses ujian setelah ditutup.")) return;
    const res = await fetch(`/api/teacher/exams/${examId}/close`, { method: "POST" });
    const data = await res.json();
    if (data.success) {
      setExams(p => p.map(e => e.id === examId ? { ...e, status: "CLOSED" } : e));
    } else {
      alert(data.error || "Gagal menutup ujian");
    }
  }

  // ── Delete ──
  async function handleDelete(id: number) {
    if (!confirm("Hapus ujian ini?")) return;
    try {
      const res = await fetch(`/api/teacher/exams/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) setExams(p => p.filter(e => e.id !== id));
      else alert("Gagal menghapus ujian");
    } catch { alert("Server error"); }
  }

  function toggleQuestion(id: number) {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  return (
    <>
      <div className="flex items-center justify-between mb-5">
        <span className="text-sm text-gray-500">{exams.length} ujian</span>
        <button className="btn btn-primary btn-sm" onClick={openCreate}>+ Buat Ujian Baru</button>
      </div>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Judul Ujian</th><th>Mapel</th><th>Kelas</th><th>Durasi</th>
              <th>Soal</th><th>Peserta</th><th>Token</th><th>Status</th><th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {exams.length === 0 && (
              <tr><td colSpan={9} className="text-center text-gray-400 py-10">Belum ada ujian</td></tr>
            )}
            {exams.map(exam => (
              <tr key={exam.id}>
                <td className="font-medium" style={{ maxWidth: "180px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {exam.title}
                </td>
                <td>{exam.subject?.name}</td>
                <td>{exam.classRoom}</td>
                <td>{exam.duration} mnt</td>
                <td>{exam._count?.examQuestions ?? 0}</td>
                <td>{exam._count?.examAttempts ?? 0}</td>
                <td>
                  {exam.token
                    ? <code style={{ fontSize: "0.75rem", background: "#f1f5f9", padding: "2px 8px", borderRadius: "6px", fontFamily: "monospace" }}>{exam.token}</code>
                    : <span className="text-gray-300">–</span>}
                </td>
                <td>
                  <span className={`badge ${exam.status === "PUBLISHED" ? "badge-green" : exam.status === "CLOSED" ? "badge-red" : "badge-gray"}`}>
                    {exam.status === "PUBLISHED" ? "Aktif" : exam.status === "CLOSED" ? "Ditutup" : "Draft"}
                  </span>
                </td>
                <td>
                  <div className="flex gap-1 flex-wrap">
                    {/* Edit - only for DRAFT */}
                    {exam.status === "DRAFT" && (
                      <button className="btn btn-ghost btn-sm" title="Edit Ujian" onClick={() => openEdit(exam)}>✏️</button>
                    )}
                    {/* Pick Questions */}
                    <button className="btn btn-ghost btn-sm" title="Pilih Soal" onClick={() => openQuestionPicker(exam)}>📝</button>
                    {/* Publish - only for DRAFT */}
                    {exam.status === "DRAFT" && (
                      <button className="btn btn-ghost btn-sm" style={{ color: "#16a34a" }} title="Publikasikan" onClick={() => handlePublish(exam.id)}>▶</button>
                    )}
                    {/* Close - only for PUBLISHED */}
                    {exam.status === "PUBLISHED" && (
                      <button className="btn btn-ghost btn-sm" style={{ color: "#dc2626" }} title="Tutup Ujian" onClick={() => handleClose(exam.id)}>🔒</button>
                    )}
                    {/* Delete */}
                    <button className="btn btn-ghost btn-sm" style={{ color: "#dc2626" }} title="Hapus" onClick={() => handleDelete(exam.id)}>🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ── Create/Edit Modal ── */}
      {showCreateModal && (
        <div
          style={{
            position: "fixed", inset: 0, zIndex: 9999,
            backgroundColor: "rgba(0,0,0,0.5)",
            display: "flex", alignItems: "center", justifyContent: "center",
            padding: "16px",
          }}
          onClick={e => { if (e.target === e.currentTarget) setShowCreateModal(false); }}
        >
          <div style={{ background: "white", borderRadius: "16px", width: "100%", maxWidth: "480px", boxShadow: "0 25px 50px rgba(0,0,0,0.2)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 24px", borderBottom: "1px solid #f1f5f9" }}>
              <h3 style={{ fontWeight: 700, fontSize: "1.1rem", margin: 0 }}>
                {editExam ? "Edit Ujian" : "Buat Ujian Baru"}
              </h3>
              <button onClick={() => setShowCreateModal(false)} style={{ background: "none", border: "none", fontSize: "1.25rem", cursor: "pointer", color: "#94a3b8" }}>✕</button>
            </div>
            <div style={{ padding: "24px" }}>
              {error && <div className="alert alert-error" style={{ marginBottom: "16px" }}>{error}</div>}
              <form onSubmit={handleSave} id="exam-form">
                <div style={{ marginBottom: "16px" }}>
                  <label className="label">Judul Ujian</label>
                  <input className="input" placeholder="e.g. UH 1 Matematika Bab 1"
                    value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} required />
                </div>
                <div style={{ marginBottom: "16px" }}>
                  <label className="label">Mata Pelajaran</label>
                  <select className="input" value={form.subjectId}
                    onChange={e => setForm(p => ({ ...p, subjectId: e.target.value }))} required>
                    <option value="">Pilih mapel...</option>
                    {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                  <div>
                    <label className="label">Kelas Target</label>
                    <input className="input" placeholder="e.g. 7A" value={form.classRoom}
                      onChange={e => setForm(p => ({ ...p, classRoom: e.target.value }))} required />
                  </div>
                  <div>
                    <label className="label">Durasi (menit)</label>
                    <input className="input" type="number" min={5} max={300} value={form.duration}
                      onChange={e => setForm(p => ({ ...p, duration: Number(e.target.value) }))} required />
                  </div>
                </div>
              </form>
            </div>
            <div style={{ display: "flex", gap: "12px", padding: "16px 24px", borderTop: "1px solid #f1f5f9" }}>
              <button type="button" className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setShowCreateModal(false)}>Batal</button>
              <button type="submit" form="exam-form" className="btn btn-primary" style={{ flex: 1 }} disabled={loading}>
                {loading ? "Menyimpan..." : editExam ? "Simpan Perubahan" : "Buat Ujian"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Question Picker Modal ── */}
      {showQuestionModal && activeExam && (
        <div
          style={{
            position: "fixed", inset: 0, zIndex: 9999,
            backgroundColor: "rgba(0,0,0,0.5)",
            overflowY: "auto",        // ← outer scrolls, not inner
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "center",
            padding: "24px 16px",
          }}
          onClick={e => { if (e.target === e.currentTarget) setShowQuestionModal(false); }}
        >
          <div style={{
            background: "white", borderRadius: "16px", width: "100%",
            maxWidth: "680px", boxShadow: "0 25px 50px rgba(0,0,0,0.2)",
            margin: "auto",
            display: "flex", flexDirection: "column",
          }}>
            {/* Header */}
            <div style={{ padding: "20px 24px", borderBottom: "1px solid #f1f5f9", flexShrink: 0, display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <h3 style={{ fontWeight: 700, fontSize: "1.1rem", margin: 0 }}>Pilih Soal — {activeExam.title}</h3>
                <p style={{ fontSize: "0.875rem", color: "#64748b", marginTop: "4px", marginBottom: 0 }}>{selectedIds.size} soal dipilih</p>
              </div>
              <button
                onClick={() => setShowQuestionModal(false)}
                style={{ background: "none", border: "none", fontSize: "1.25rem", cursor: "pointer", color: "#94a3b8", padding: "4px 8px", marginTop: "-4px" }}
              >✕</button>
            </div>

            {/* Body — NO maxHeight, outer wrapper scrolls */}
            <div style={{ padding: "16px 24px" }}>
              {availableQuestions.length === 0 && (
                <p style={{ textAlign: "center", color: "#94a3b8", padding: "32px 0" }}>
                  Tidak ada soal. Buat soal di Bank Soal dahulu.
                </p>
              )}
              {availableQuestions.map((q, i) => (
                <label
                  key={q.id}
                  style={{
                    display: "flex", alignItems: "flex-start", gap: "12px",
                    padding: "12px", borderRadius: "12px", marginBottom: "8px",
                    border: `2px solid ${selectedIds.has(q.id) ? "#2563eb" : "#f1f5f9"}`,
                    background: selectedIds.has(q.id) ? "#eff6ff" : "white",
                    cursor: "pointer",
                  }}
                >
                  <input
                    type="checkbox"
                    checked={selectedIds.has(q.id)}
                    onChange={() => toggleQuestion(q.id)}
                    style={{ marginTop: "3px", flexShrink: 0 }}
                  />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", gap: "8px", marginBottom: "4px", alignItems: "center", flexWrap: "wrap" }}>
                      <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>#{i + 1}</span>
                      <span className={`badge ${q.type === "MULTIPLE_CHOICE" ? "badge-purple" : "badge-yellow"}`} style={{ fontSize: "0.7rem" }}>
                        {q.type === "MULTIPLE_CHOICE" ? "PG" : "Essay"}
                      </span>
                      <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>{q.points} poin</span>
                    </div>
                    <p style={{ fontSize: "0.875rem", margin: 0, wordBreak: "break-word" }}>{q.body}</p>
                  </div>
                </label>
              ))}
            </div>

            {/* Footer — always visible, sticks to bottom of modal */}
            <div style={{ display: "flex", gap: "12px", padding: "16px 24px", borderTop: "1px solid #f1f5f9", flexShrink: 0, position: "sticky", bottom: 0, background: "white", borderRadius: "0 0 16px 16px" }}>
              <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setShowQuestionModal(false)}>Batal</button>
              <button className="btn btn-primary" style={{ flex: 1 }} onClick={saveQuestions} disabled={loading}>
                {loading ? "Menyimpan..." : `Simpan (${selectedIds.size} soal)`}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
