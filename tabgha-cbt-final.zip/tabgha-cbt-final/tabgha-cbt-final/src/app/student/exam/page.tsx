"use client";
// src/app/student/exam/page.tsx
import { useState } from "react";
import { useRouter } from "next/navigation";

type Step = "identity" | "token";

export default function StudentExamEntryPage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>("identity");
  const [identity, setIdentity] = useState({ name: "", classRoom: "" });
  const [token, setToken] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleIdentityNext(e: React.FormEvent) {
    e.preventDefault();
    if (!identity.name || !identity.classRoom) { setError("Lengkapi data diri"); return; }
    setError("");
    setStep("token");
  }

  async function handleJoin(e: React.FormEvent) {
    e.preventDefault();
    if (!token.trim()) { setError("Masukkan token ujian"); return; }
    setLoading(true); setError("");
    try {
      const res = await fetch("/api/student/exam/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: token.trim().toUpperCase(), studentName: identity.name, classRoom: identity.classRoom }),
      });
      const data = await res.json();
      if (!data.success) { setError(data.error || "Token tidak valid"); setLoading(false); return; }
      router.push(`/exam/${data.data.attemptId}`);
    } catch { setError("Server error"); setLoading(false); }
  }

  return (
    <div className="p-8 max-w-md mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Ikuti Ujian</h1>
        <p className="text-gray-500 mt-1">
          {step === "identity" ? "Konfirmasi identitas Anda terlebih dahulu." : "Masukkan token dari guru."}
        </p>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-2 mb-8">
        {(["identity", "token"] as Step[]).map((s, i) => (
          <div key={s} className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold
              ${step === s || (s === "identity" && step === "token") ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-400"}`}>
              {i + 1}
            </div>
            <span className={`text-sm ${step === s ? "font-semibold text-gray-900" : "text-gray-400"}`}>
              {s === "identity" ? "Identitas" : "Token Ujian"}
            </span>
            {i === 0 && <div className="w-8 h-px bg-gray-300 mx-1" />}
          </div>
        ))}
      </div>

      {error && <div className="alert alert-error mb-4">{error}</div>}

      {step === "identity" && (
        <div className="card">
          <h2 className="font-bold text-lg mb-5">Identitas Siswa</h2>
          <form onSubmit={handleIdentityNext} className="space-y-4">
            <div>
              <label className="label">Nama Siswa</label>
              <input className="input" placeholder="Nama lengkap Anda"
                value={identity.name} onChange={e => setIdentity(p => ({...p, name: e.target.value}))} required />
            </div>
            <div>
              <label className="label">Kelas</label>
              <input className="input" placeholder="e.g. 7A"
                value={identity.classRoom} onChange={e => setIdentity(p => ({...p, classRoom: e.target.value}))} required />
            </div>
            <button type="submit" className="btn btn-primary w-full">Berikutnya →</button>
          </form>
        </div>
      )}

      {step === "token" && (
        <div className="card">
          <h2 className="font-bold text-lg mb-1">Token Ujian</h2>
          <p className="text-sm text-gray-500 mb-5">Masukkan token 8 karakter yang diberikan guru.</p>
          <form onSubmit={handleJoin} className="space-y-4">
            <div>
              <label className="label">Token</label>
              <input
                className="input text-center text-2xl font-mono tracking-widest uppercase"
                placeholder="XXXXXXXX"
                maxLength={8}
                value={token}
                onChange={e => setToken(e.target.value.toUpperCase())}
                required
                autoFocus
              />
            </div>
            <div className="flex gap-3">
              <button type="button" className="btn btn-ghost flex-1" onClick={() => { setStep("identity"); setError(""); }}>
                ← Kembali
              </button>
              <button type="submit" className="btn btn-primary flex-1" disabled={loading}>
                {loading ? "Memuat..." : "Mulai Ujian"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
