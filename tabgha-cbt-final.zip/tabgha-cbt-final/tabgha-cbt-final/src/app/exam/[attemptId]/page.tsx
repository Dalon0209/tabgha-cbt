"use client";
// src/app/student/exam/[attemptId]/page.tsx
import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter, useParams } from "next/navigation";
import type { Question, ExamAttempt, Exam } from "@/types";

interface ExamData {
  attempt: ExamAttempt;
  exam: Exam & { questions: Question[] };
}

export default function ExamTakingPage() {
  const router = useRouter();
  const params = useParams();
  const attemptId = Number(params.attemptId);

  const [data, setData] = useState<ExamData | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [currentIdx, setCurrentIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [cheatCount, setCheatCount] = useState(0);
  const [showCheatWarning, setShowCheatWarning] = useState(false);
  const [cheatMessage, setCheatMessage] = useState("");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hasFetched = useRef(false);
  const warningTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isSubmittingRef = useRef(false); // suppress cheat detection during submit

  // ── Load exam data ──────────────────────────────────────────────────────
  useEffect(() => {
    if (hasFetched.current) return;
    hasFetched.current = true;

    fetch(`/api/student/exam/${attemptId}`)
      .then(r => r.json())
      .then(d => {
        if (!d.success) { router.push("/student/dashboard"); return; }
        setData(d.data);
        setAnswers(d.data.attempt.answers || {});
        const elapsed = Math.floor((Date.now() - new Date(d.data.attempt.startedAt).getTime()) / 1000);
        const totalSecs = d.data.exam.duration * 60;
        setTimeLeft(Math.max(0, totalSecs - elapsed));
        setLoading(false);
        // Auto enter fullscreen on load
        enterFullscreen();
      })
      .catch(() => router.push("/student/dashboard"));
  }, [attemptId, router]);

  // ── Fullscreen helpers ──────────────────────────────────────────────────
  function enterFullscreen() {
    const el = document.documentElement;
    if (el.requestFullscreen) el.requestFullscreen();
    setIsFullscreen(true);
  }

  function handleExitFullscreen() {
    if (document.exitFullscreen) document.exitFullscreen();
    setIsFullscreen(false);
  }

  // ── Countdown timer ─────────────────────────────────────────────────────
  useEffect(() => {
    if (!data || timeLeft <= 0) return;
    intervalRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(intervalRef.current!);
          handleSubmit(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(intervalRef.current!);
  }, [data]); // eslint-disable-line

  // ── Show cheat warning overlay ──────────────────────────────────────────
  const showWarning = useCallback((message: string) => {
    setCheatMessage(message);
    setShowCheatWarning(true);
    if (warningTimeout.current) clearTimeout(warningTimeout.current);
    warningTimeout.current = setTimeout(() => setShowCheatWarning(false), 4000);
  }, []);

  // ── Log cheat to server ─────────────────────────────────────────────────
  const logCheat = useCallback(async (type: string, message: string) => {
    setCheatCount(p => p + 1);
    showWarning(message);
    await fetch(`/api/student/exam/${attemptId}/cheat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type }),
    });
  }, [attemptId, showWarning]);

  // ── Anti-cheat event listeners ──────────────────────────────────────────
  useEffect(() => {
    if (!data) return;

    // Block visibility change (tab switch, minimize)
    const onVisibilityChange = () => {
      if (document.hidden && !isSubmittingRef.current) {
        logCheat("TAB_SWITCH", "⚠️ Anda berpindah tab! Tindakan ini telah dicatat.");
      }
    };

    // Block window blur
    const onBlur = () => {
      if (!isSubmittingRef.current) {
        logCheat("BLUR_FOCUS", "⚠️ Anda keluar dari jendela ujian! Tindakan ini telah dicatat.");
      }
    };

    // Block fullscreen exit — force back into fullscreen immediately
    const onFullscreenChange = () => {
      if (!document.fullscreenElement && !isSubmittingRef.current) {
        setIsFullscreen(false);
        logCheat("SCREEN_MINIMIZE", "⚠️ Anda keluar dari layar penuh! Tindakan ini telah dicatat.");
        // Force re-enter fullscreen after a short delay so browser allows the call
        setTimeout(() => {
          if (!document.fullscreenElement && !isSubmittingRef.current) {
            document.documentElement.requestFullscreen().catch(() => {});
            setIsFullscreen(true);
          }
        }, 300);
      }
    };

    // Block keyboard shortcuts that open new tabs / leave page
    const onKeyDown = (e: KeyboardEvent) => {
      // Block Ctrl+T (new tab), Ctrl+W (close tab), Ctrl+N (new window)
      // Alt+F4, F11, Ctrl+R (refresh), Ctrl+Tab
      const blocked = [
        (e.ctrlKey && e.key === "t"),
        (e.ctrlKey && e.key === "w"),
        (e.ctrlKey && e.key === "n"),
        (e.ctrlKey && e.key === "r"),
        (e.ctrlKey && e.shiftKey && e.key === "Tab"),
        (e.ctrlKey && e.key === "Tab"),
        (e.altKey && e.key === "F4"),
        (e.key === "F5"),
        (e.key === "Escape"),
      ];
      if (blocked.some(Boolean)) {
        e.preventDefault();
        e.stopPropagation();
        logCheat("TAB_SWITCH", "⚠️ Shortcut keyboard diblokir! Tindakan ini telah dicatat.");
        return false;
      }
    };

    // Block right-click
    const onContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      return false;
    };

    // Block copy/paste
    const onCopy = (e: ClipboardEvent) => e.preventDefault();
    const onPaste = (e: ClipboardEvent) => e.preventDefault();

    // Block beforeunload (closing tab)
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "Ujian sedang berlangsung. Apakah Anda yakin ingin keluar?";
      return e.returnValue;
    };

    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("blur", onBlur);
    document.addEventListener("fullscreenchange", onFullscreenChange);
    document.addEventListener("keydown", onKeyDown, true);
    document.addEventListener("contextmenu", onContextMenu);
    document.addEventListener("copy", onCopy);
    document.addEventListener("paste", onPaste);
    window.addEventListener("beforeunload", onBeforeUnload);

    return () => {
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("blur", onBlur);
      document.removeEventListener("fullscreenchange", onFullscreenChange);
      document.removeEventListener("keydown", onKeyDown, true);
      document.removeEventListener("contextmenu", onContextMenu);
      document.removeEventListener("copy", onCopy);
      document.removeEventListener("paste", onPaste);
      window.removeEventListener("beforeunload", onBeforeUnload);
    };
  }, [data, logCheat]);

  // ── Auto-save answers ───────────────────────────────────────────────────
  const saveAnswers = useCallback(async (newAnswers: Record<number, string>) => {
    await fetch(`/api/student/exam/${attemptId}/answer`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ answers: newAnswers }),
    });
  }, [attemptId]);

  function handleAnswer(questionId: number, value: string) {
    const next = { ...answers, [questionId]: value };
    setAnswers(next);
    saveAnswers(next);
  }

  // ── Submit ──────────────────────────────────────────────────────────────
  async function handleSubmit(auto = false) {
    if (submitting) return;
    isSubmittingRef.current = true; // disable cheat detection before exiting fullscreen
    setSubmitting(true);
    setShowConfirm(false);
    clearInterval(intervalRef.current!);
    // Exit fullscreen on submit (won't trigger cheat log due to isSubmittingRef)
    if (document.fullscreenElement) document.exitFullscreen();

    try {
      await fetch(`/api/student/exam/${attemptId}/submit`, { method: "POST" });
      router.push(`/exam/${attemptId}/result`);
    } catch {
      isSubmittingRef.current = false;
      setSubmitting(false);
    }
  }

  // ── Timer format ────────────────────────────────────────────────────────
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const timerColor = timeLeft < 300 ? "#dc2626" : timeLeft < 600 ? "#d97706" : "#16a34a";

  if (loading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: "3rem", marginBottom: "16px" }}>⏳</div>
          <p style={{ color: "#64748b" }}>Memuat ujian...</p>
        </div>
      </div>
    );
  }

  if (!data) return null;

  const { exam } = data;
  const questions = exam.questions;
  const currentQ = questions[currentIdx];
  const answered = Object.keys(answers).length;

  return (
    <div className="exam-mode" style={{ display: "flex", flexDirection: "column", height: "100vh", background: "#f8fafc", userSelect: "none", position: "relative" }}>

      {/* ── School Logo Watermark ── */}
      <div aria-hidden="true" style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <img src="/logo.png" alt="" style={{ width: "480px", maxWidth: "55vw", opacity: 0.045, filter: "grayscale(100%)", userSelect: "none" } as React.CSSProperties} />
      </div>

      {/* ── Cheat Warning Overlay ── */}
      {showCheatWarning && (
        <div style={{
          position: "fixed", top: 0, left: 0, right: 0, zIndex: 99999,
          background: "#dc2626", color: "white",
          padding: "16px 24px",
          display: "flex", alignItems: "center", gap: "12px",
          boxShadow: "0 4px 20px rgba(220,38,38,0.5)",
          animation: "slideDown 0.3s ease",
        }}>
          <span style={{ fontSize: "1.5rem" }}>🚨</span>
          <div>
            <strong style={{ fontSize: "1rem" }}>{cheatMessage}</strong>
            <div style={{ fontSize: "0.8rem", opacity: 0.9 }}>
              Total pelanggaran: {cheatCount} kali — Semua aktivitas dicatat dan dilaporkan ke guru.
            </div>
          </div>
        </div>
      )}

      {/* ── Fullscreen reminder banner ── */}
      {!isFullscreen && !loading && (
        <div style={{
          background: "#d97706", color: "white", padding: "10px 20px",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          flexShrink: 0, position: "relative", zIndex: 10,
        }}>
          <span style={{ fontSize: "0.875rem" }}>⚠️ Anda keluar dari mode layar penuh. Kembali ke layar penuh untuk melanjutkan ujian.</span>
          <button
            onClick={enterFullscreen}
            style={{ background: "white", color: "#d97706", border: "none", padding: "6px 16px", borderRadius: "8px", fontWeight: 700, cursor: "pointer", fontSize: "0.8rem" }}
          >
            Kembali Layar Penuh
          </button>
        </div>
      )}

      {/* ── Top bar ── */}
      <div style={{
        background: "white", borderBottom: "1px solid #e2e8f0",
        padding: "12px 24px", display: "flex", alignItems: "center",
        justifyContent: "space-between", flexShrink: 0, position: "relative", zIndex: 10,
      }}>
        <div>
          <div style={{ fontWeight: 700, color: "#0f172a", fontSize: "0.9rem" }}>{exam.title}</div>
          <div style={{ fontSize: "0.75rem", color: "#94a3b8" }}>{exam.subject?.name} · Kelas {exam.classRoom}</div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
          {cheatCount > 0 && (
            <div style={{ color: "#dc2626", fontSize: "0.8rem", fontWeight: 700, display: "flex", alignItems: "center", gap: "4px" }}>
              🚨 {cheatCount} pelanggaran
            </div>
          )}
          <div style={{ fontSize: "0.875rem", color: "#64748b" }}>
            <span style={{ fontWeight: 700, color: "#2563eb" }}>{answered}</span>/{questions.length} dijawab
          </div>
          {/* Timer */}
          <div style={{
            fontFamily: "monospace", fontSize: "1.5rem", fontWeight: 800,
            padding: "6px 16px", borderRadius: "10px", tabularNums: true,
            color: timerColor, background: `${timerColor}18`,
          } as React.CSSProperties}>
            {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
          </div>
          <button
            style={{ background: "#16a34a", color: "white", border: "none", padding: "8px 20px", borderRadius: "8px", fontWeight: 700, cursor: "pointer", fontSize: "0.875rem" }}
            onClick={() => setShowConfirm(true)}
            disabled={submitting}
          >
            {submitting ? "Mengirim..." : "Kirim Jawaban"}
          </button>
        </div>
      </div>

      <div style={{ display: "flex", flex: 1, overflow: "hidden", position: "relative", zIndex: 10 }}>
        {/* ── Question area ── */}
        <div style={{ flex: 1, overflowY: "auto", padding: "32px" }}>
          <div style={{ maxWidth: "680px", margin: "0 auto" }}>
            {/* Question header */}
            <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "20px" }}>
              <span style={{
                width: "36px", height: "36px", borderRadius: "10px",
                background: "#2563eb", color: "white",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontWeight: 700, fontSize: "0.875rem", flexShrink: 0,
              }}>{currentIdx + 1}</span>
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <span className={`badge ${currentQ.type === "MULTIPLE_CHOICE" ? "badge-purple" : "badge-yellow"}`} style={{ fontSize: "0.75rem" }}>
                  {currentQ.type === "MULTIPLE_CHOICE" ? "Pilihan Ganda" : "Essay"}
                </span>
                <span style={{ fontSize: "0.75rem", color: "#94a3b8" }}>{currentQ.points} poin</span>
              </div>
            </div>

            {/* Question body */}
            <div className="card" style={{ marginBottom: "20px" }}>
              {currentQ.imageUrl && (
                <div style={{ marginBottom: "16px", borderRadius: "10px", overflow: "hidden", border: "1px solid #f1f5f9" }}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={currentQ.imageUrl} alt="Gambar soal" style={{ width: "100%", maxHeight: "256px", objectFit: "contain", background: "#f8fafc" }} />
                </div>
              )}
              {currentQ.videoUrl && (
                <div style={{ marginBottom: "16px" }}>
                  <iframe src={currentQ.videoUrl} style={{ width: "100%", aspectRatio: "16/9", borderRadius: "10px" }} allowFullScreen />
                </div>
              )}
              <p style={{ color: "#0f172a", lineHeight: 1.7, fontSize: "1rem", margin: 0 }}>{currentQ.body}</p>
            </div>

            {/* Multiple choice */}
            {currentQ.type === "MULTIPLE_CHOICE" && (
              <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                {(["A", "B", "C", "D"] as const).map(opt => {
                  const text = currentQ[`option${opt}` as "optionA"];
                  if (!text) return null;
                  const selected = answers[currentQ.id] === opt;
                  return (
                    <button
                      key={opt}
                      onClick={() => handleAnswer(currentQ.id, opt)}
                      style={{
                        display: "flex", alignItems: "center", gap: "16px",
                        padding: "14px 18px", borderRadius: "12px", textAlign: "left",
                        border: `2px solid ${selected ? "#2563eb" : "#e2e8f0"}`,
                        background: selected ? "#eff6ff" : "white",
                        cursor: "pointer", transition: "all 0.15s",
                        width: "100%",
                      }}
                    >
                      <span style={{
                        width: "32px", height: "32px", borderRadius: "50%",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontWeight: 700, fontSize: "0.875rem", flexShrink: 0,
                        background: selected ? "#2563eb" : "#f1f5f9",
                        color: selected ? "white" : "#64748b",
                      }}>{opt}</span>
                      <span style={{ color: "#0f172a" }}>{text}</span>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Essay */}
            {currentQ.type === "ESSAY" && (
              <div>
                <label className="label">Jawaban Essay</label>
                <textarea
                  className="input"
                  style={{ minHeight: "160px", resize: "vertical" }}
                  placeholder="Tulis jawaban Anda di sini..."
                  value={answers[currentQ.id] || ""}
                  onChange={e => handleAnswer(currentQ.id, e.target.value)}
                />
              </div>
            )}

            {/* Navigation */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: "32px" }}>
              <button
                className="btn btn-outline btn-sm"
                onClick={() => setCurrentIdx(p => Math.max(0, p - 1))}
                disabled={currentIdx === 0}
              >← Sebelumnya</button>
              <span style={{ fontSize: "0.875rem", color: "#94a3b8" }}>{currentIdx + 1} / {questions.length}</span>
              <button
                className="btn btn-primary btn-sm"
                onClick={() => setCurrentIdx(p => Math.min(questions.length - 1, p + 1))}
                disabled={currentIdx === questions.length - 1}
              >Berikutnya →</button>
            </div>
          </div>
        </div>

        {/* ── Question navigator sidebar ── */}
        <div style={{ width: "200px", borderLeft: "1px solid #e2e8f0", background: "white", padding: "16px", overflowY: "auto", flexShrink: 0 }}>
          <p style={{ fontSize: "0.7rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: "#94a3b8", marginBottom: "12px" }}>
            Navigasi Soal
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "6px" }}>
            {questions.map((q, i) => {
              const isAnswered = !!answers[q.id];
              const isCurrent = i === currentIdx;
              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentIdx(i)}
                  style={{
                    aspectRatio: "1", borderRadius: "8px", fontSize: "0.75rem", fontWeight: 700,
                    border: isCurrent ? "2px solid #2563eb" : "none",
                    background: isCurrent ? "#2563eb" : isAnswered ? "#dcfce7" : "#f1f5f9",
                    color: isCurrent ? "white" : isAnswered ? "#15803d" : "#94a3b8",
                    cursor: "pointer",
                  }}
                >{i + 1}</button>
              );
            })}
          </div>
          <div style={{ marginTop: "16px", display: "flex", flexDirection: "column", gap: "6px" }}>
            {[
              { color: "#dcfce7", label: "Sudah dijawab" },
              { color: "#f1f5f9", label: "Belum dijawab" },
              { color: "#2563eb", label: "Soal aktif", textColor: "white" },
            ].map(item => (
              <div key={item.label} style={{ display: "flex", alignItems: "center", gap: "8px", fontSize: "0.72rem", color: "#64748b" }}>
                <div style={{ width: "12px", height: "12px", borderRadius: "4px", background: item.color, flexShrink: 0 }} />
                {item.label}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Confirm submit modal ── */}
      {showConfirm && (
        <div style={{
          position: "fixed", inset: 0, zIndex: 99998,
          background: "rgba(0,0,0,0.6)",
          display: "flex", alignItems: "center", justifyContent: "center",
          padding: "16px",
        }}>
          <div style={{ background: "white", borderRadius: "20px", padding: "40px 32px", maxWidth: "400px", width: "100%", textAlign: "center", boxShadow: "0 25px 50px rgba(0,0,0,0.3)" }}>
            <div style={{ fontSize: "3.5rem", marginBottom: "16px" }}>📨</div>
            <h3 style={{ fontSize: "1.25rem", fontWeight: 700, marginBottom: "8px" }}>Kirim Jawaban?</h3>
            <p style={{ color: "#64748b", fontSize: "0.875rem", marginBottom: "8px" }}>
              Anda telah menjawab <strong>{answered}</strong> dari <strong>{questions.length}</strong> soal.
            </p>
            {answered < questions.length && (
              <div className="alert alert-warning" style={{ marginBottom: "16px", fontSize: "0.875rem" }}>
                ⚠️ {questions.length - answered} soal belum dijawab!
              </div>
            )}
            <p style={{ color: "#64748b", fontSize: "0.875rem", marginBottom: "24px" }}>
              Apakah Anda yakin ingin mengirimkan jawaban?
            </p>
            <div style={{ display: "flex", gap: "12px" }}>
              <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setShowConfirm(false)}>Batal</button>
              <button className="btn btn-success" style={{ flex: 1 }} onClick={() => handleSubmit(false)} disabled={submitting}>
                {submitting ? "Mengirim..." : "Kirim"}
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideDown {
          from { transform: translateY(-100%); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
