// src/app/exam/[attemptId]/layout.tsx
// Standalone layout — completely outside StudentLayout.
// No sidebar, no nav. The exam page owns the full viewport.
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export default async function ExamStandaloneLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user || user.role !== "STUDENT") redirect("/login");
  return <>{children}</>;
}
