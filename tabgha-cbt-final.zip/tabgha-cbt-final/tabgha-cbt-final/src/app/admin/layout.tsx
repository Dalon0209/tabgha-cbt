// src/app/admin/layout.tsx
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import AdminSidebar from "@/components/admin/AdminSidebar";
import Watermark from "@/components/Watermark";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user || user.role !== "ADMIN") redirect("/login");

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden" style={{ position: "relative" }}>
      <Watermark />
      <AdminSidebar user={user} />
      <main className="flex-1 overflow-y-auto" style={{ position: "relative", zIndex: 1 }}>
        <div className="page-enter">{children}</div>
      </main>
    </div>
  );
}
