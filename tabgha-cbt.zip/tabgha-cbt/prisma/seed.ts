// prisma/seed.ts
// Run: npx ts-node prisma/seed.ts
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding Tabgha CBT database...");

  // System settings
  await prisma.systemSetting.upsert({
    where: { id: 1 },
    create: { id: 1, schoolName: "SMP Tabgha", activeTerm: "Semester 1 2024/2025", schoolLevel: "SMP" },
    update: {},
  });
  console.log("✓ System settings created");

  // Admin
  const adminPass = await bcrypt.hash("admin123", 12);
  await prisma.user.upsert({
    where: { username: "admin" },
    create: { username: "admin", password: adminPass, name: "Administrator", role: "ADMIN" },
    update: {},
  });
  console.log("✓ Admin user: admin / admin123");

  // Demo teacher
  const teacherPass = await bcrypt.hash("guru123", 12);
  const teacher = await prisma.user.upsert({
    where: { username: "guru_matematika" },
    create: { username: "guru_matematika", password: teacherPass, name: "Budi Santoso", role: "TEACHER" },
    update: {},
  });
  console.log("✓ Teacher: guru_matematika / guru123");

  // Demo subject
  const subject = await prisma.subject.upsert({
    where: { code: "MTK7" },
    create: { name: "Matematika Kelas 7", code: "MTK7", creatorId: teacher.id },
    update: {},
  });
  console.log("✓ Subject: Matematika Kelas 7");

  // Demo questions
  const questions = await Promise.all([
    prisma.question.create({
      data: {
        subjectId: subject.id,
        type: "MULTIPLE_CHOICE",
        body: "Berapakah hasil dari 7 × 8?",
        optionA: "54",
        optionB: "56",
        optionC: "58",
        optionD: "60",
        correctOpt: "B",
        points: 10,
      },
    }),
    prisma.question.create({
      data: {
        subjectId: subject.id,
        type: "MULTIPLE_CHOICE",
        body: "Manakah yang merupakan bilangan prima?",
        optionA: "4",
        optionB: "6",
        optionC: "7",
        optionD: "9",
        correctOpt: "C",
        points: 10,
      },
    }),
    prisma.question.create({
      data: {
        subjectId: subject.id,
        type: "MULTIPLE_CHOICE",
        body: "Hasil dari 15² adalah?",
        optionA: "200",
        optionB: "215",
        optionC: "225",
        optionD: "235",
        correctOpt: "C",
        points: 10,
      },
    }),
    prisma.question.create({
      data: {
        subjectId: subject.id,
        type: "ESSAY",
        body: "Jelaskan pengertian bilangan bulat dan berikan 3 contohnya!",
        points: 20,
      },
    }),
  ]);
  console.log(`✓ ${questions.length} demo questions created`);

  // Demo students
  const studentPass = await bcrypt.hash("siswa123", 12);
  for (const [username, name, cls] of [
    ["siswa_001", "Ahmad Fauzi", "7A"],
    ["siswa_002", "Siti Rahayu", "7A"],
    ["siswa_003", "Budi Prasetyo", "7B"],
  ]) {
    await prisma.user.upsert({
      where: { username },
      create: { username, password: studentPass, name, role: "STUDENT", classRoom: cls },
      update: {},
    });
  }
  console.log("✓ Demo students: siswa_001, siswa_002, siswa_003 / siswa123");

  console.log("\n🎉 Seeding complete!");
  console.log("\n📋 Login credentials:");
  console.log("  Admin    : admin / admin123");
  console.log("  Guru     : guru_matematika / guru123");
  console.log("  Siswa    : siswa_001 / siswa123");
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
