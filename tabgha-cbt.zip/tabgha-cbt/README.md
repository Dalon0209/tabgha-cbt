# Tabgha CBT – Academic Computer-Based Test System

> High-performance, web-based assessment platform engineered exclusively for **SMP Tabgha** institutions.

![Next.js](https://img.shields.io/badge/Next.js-16.2.1-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5.5-blue)
![Prisma](https://img.shields.io/badge/Prisma-5.21.1-teal)
![MySQL](https://img.shields.io/badge/MySQL-8.0-orange)

---

## Features

- **Role-Based Access Control** — Admin, Teacher, Student with separate dashboards
- **Dynamic Exam Engine** — Multiple choice + Essay, multimedia (image/video URL) support  
- **Anti-Cheat System** — Detects tab switches, window blur, screen minimize; logs to CheatLog
- **High-Volume Data Tools** — Bulk CSV student import; export results to Excel & PDF
- **Real-time Timer** — Countdown with auto-submit on expiry
- **Question Bank** — Per-subject, reusable across multiple exams

---

## Quick Start

```bash
# 1. Clone
git clone https://github.com/Dalon0209/tabgha-cbt.git
cd tabgha-cbt

# 2. Install
npm install

# 3. Configure
cp .env.example .env
# Edit .env → set DATABASE_URL and JWT_SECRET

# 4. Database
npx prisma generate
npx prisma db push

# 5. Seed demo data
npx ts-node prisma/seed.ts

# 6. Run
npm run dev        # http://localhost:3003
```

## Default Credentials (after seeding)

| Role    | Username          | Password   |
|---------|-------------------|------------|
| Admin   | `admin`           | `admin123` |
| Guru    | `guru_matematika` | `guru123`  |
| Siswa   | `siswa_001`       | `siswa123` |

---

## Tech Stack

| Layer         | Technology                     |
|---------------|--------------------------------|
| Framework     | Next.js 16.2.1 (App Router)    |
| Language      | TypeScript                     |
| UI            | React + Tailwind CSS v4        |
| Database      | MySQL 8.0                      |
| ORM           | Prisma 5.21.1                  |
| Auth          | JWT (jsonwebtoken) + bcryptjs  |
| CSV Import    | papaparse                      |
| Excel Export  | exceljs                        |
| PDF Export    | jspdf + jspdf-autotable        |

---

## CSV Import Format

For bulk student import (Admin → Manajemen Pengguna → Import CSV):

```
username,password,name,role,classRoom
siswa_004,password123,Andi Wijaya,STUDENT,7A
guru_ipa,password123,Dr. Sari Dewi,TEACHER,
```

## License

Private – SMP Tabgha Academic Use Only
