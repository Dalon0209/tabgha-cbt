"use client";
// src/components/admin/AdminSidebar.tsx
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import type { JWTPayload } from "@/lib/auth";

const navItems = [
  { href: "/admin/dashboard", label: "Dashboard", icon: "▦" },
  { href: "/admin/users", label: "Manajemen Pengguna", icon: "👥" },
  { href: "/admin/settings", label: "Pengaturan Sistem", icon: "⚙️" },
  { href: "/admin/exams", label: "Monitor Ujian", icon: "📋" },
  { href: "/admin/reports", label: "Laporan & Ekspor", icon: "📊" },
];

export default function AdminSidebar({ user }: { user: JWTPayload }) {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  }

  return (
    <aside className="w-64 h-full flex flex-col border-r border-gray-200 bg-white shrink-0">
      {/* Brand */}
      <div className="p-5 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-bold text-sm"
            style={{ background: "var(--color-admin)" }}>T</div>
          <div>
            <div className="font-bold text-sm text-gray-900">Tabgha CBT</div>
            <div className="text-xs text-gray-400">Admin Panel</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {navItems.map(item => (
          <Link
            key={item.href}
            href={item.href}
            className={`sidebar-link ${pathname.startsWith(item.href) ? "active" : ""}`}
          >
            <span className="text-base w-5 text-center">{item.icon}</span>
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>

      {/* User */}
      <div className="p-3 border-t border-gray-100">
        <div className="flex items-center gap-2 px-2 py-2 mb-1">
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white"
            style={{ background: "var(--color-admin)" }}>
            {user.name[0].toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold truncate">{user.name}</div>
            <div className="text-xs text-gray-400">Administrator</div>
          </div>
        </div>
        <button onClick={handleLogout} className="btn btn-ghost btn-sm w-full justify-start text-red-500 hover:bg-red-50">
          🚪 Keluar
        </button>
      </div>
    </aside>
  );
}
