// src/types/index.ts

export type Role = "ADMIN" | "TEACHER" | "STUDENT";
export type QuestionType = "MULTIPLE_CHOICE" | "ESSAY";
export type ExamStatus = "DRAFT" | "PUBLISHED";
export type CheatType = "TAB_SWITCH" | "SCREEN_MINIMIZE" | "DESKTOP_CHANGE" | "BLUR_FOCUS";

export interface User {
  id: number;
  username: string;
  name: string;
  role: Role;
  classRoom?: string | null;
  createdAt: string;
}

export interface Subject {
  id: number;
  name: string;
  code: string;
  creatorId: number;
  creator?: Pick<User, "id" | "name">;
  _count?: { questions: number; exams: number };
}

export interface Question {
  id: number;
  subjectId: number;
  subject?: Pick<Subject, "id" | "name">;
  type: QuestionType;
  body: string;
  imageUrl?: string | null;
  videoUrl?: string | null;
  optionA?: string | null;
  optionB?: string | null;
  optionC?: string | null;
  optionD?: string | null;
  correctOpt?: string | null;
  points: number;
}

export interface Exam {
  id: number;
  title: string;
  subjectId: number;
  subject?: Pick<Subject, "id" | "name">;
  creatorId: number;
  creator?: Pick<User, "id" | "name">;
  classRoom: string;
  duration: number;
  status: ExamStatus;
  token?: string | null;
  startTime?: string | null;
  endTime?: string | null;
  createdAt: string;
  _count?: { examQuestions: number; examAttempts: number };
}

export interface ExamAttempt {
  id: number;
  examId: number;
  exam?: Pick<Exam, "id" | "title" | "duration">;
  studentId: number;
  student?: Pick<User, "id" | "name" | "classRoom">;
  answers: Record<string, string>;
  score?: number | null;
  maxScore?: number | null;
  isSubmitted: boolean;
  isValid: boolean;
  startedAt: string;
  submittedAt?: string | null;
  cheatLogs?: CheatLog[];
}

export interface CheatLog {
  id: number;
  attemptId: number;
  type: CheatType;
  timestamp: string;
}

export interface SystemSetting {
  id: number;
  schoolName: string;
  activeTerm: string;
  schoolLevel: string;
}

// API response wrapper
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// Pagination
export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}
