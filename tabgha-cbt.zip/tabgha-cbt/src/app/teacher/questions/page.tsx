// src/app/teacher/questions/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import QuestionsClient from "./QuestionsClient";

export default async function QuestionsPage() {
  const user = await getCurrentUser();
  const [subjects, questions] = await Promise.all([
    prisma.subject.findMany({ where: { creatorId: user!.userId }, orderBy: { name: "asc" } }),
    prisma.question.findMany({
      where: { subject: { creatorId: user!.userId } },
      include: { subject: { select: { id: true, name: true } } },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Bank Soal</h1>
        <p className="text-gray-500 mt-1">Buat dan kelola soal pilihan ganda dan essay.</p>
      </div>
      <QuestionsClient
        initialQuestions={questions.map(q => ({ ...q, imageUrl: q.imageUrl ?? undefined, videoUrl: q.videoUrl ?? undefined, optionA: q.optionA ?? undefined, optionB: q.optionB ?? undefined, optionC: q.optionC ?? undefined, optionD: q.optionD ?? undefined, correctOpt: q.correctOpt ?? undefined }))}
        subjects={subjects}
      />
    </div>
  );
}
