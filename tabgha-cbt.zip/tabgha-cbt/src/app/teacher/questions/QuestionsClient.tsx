"use client";
// src/app/teacher/questions/QuestionsClient.tsx
import { useState } from "react";
import type { Question, Subject } from "@/types";

const defaultForm = {
  subjectId: "", type: "MULTIPLE_CHOICE", body: "", imageUrl: "", videoUrl: "",
  optionA: "", optionB: "", optionC: "", optionD: "", correctOpt: "A", points: 1,
};

export default function QuestionsClient({
  initialQuestions, subjects,
}: { initialQuestions: Question[]; subjects: Subject[] }) {
  const [questions, setQuestions] = useState(initialQuestions);
  const [showModal, setShowModal] = useState(false);
  const [editQ, setEditQ] = useState<Question | null>(null);
  const [form, setForm] = useState({ ...defaultForm });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [filterSubject, setFilterSubject] = useState("ALL");
  const [filterType, setFilterType] = useState("ALL");

  const filtered = questions.filter(q => {
    const ms = filterSubject === "ALL" || String(q.subjectId) === filterSubject;
    const mt = filterType === "ALL" || q.type === filterType;
    return ms && mt;
  });

  function openAdd() { setEditQ(null); setForm({ ...defaultForm, subjectId: subjects[0]?.id?.toString() || "" }); setError(""); setShowModal(true); }
  function openEdit(q: Question) {
    setEditQ(q);
    setForm({
      subjectId: String(q.subjectId), type: q.type, body: q.body,
      imageUrl: q.imageUrl || "", videoUrl: q.videoUrl || "",
      optionA: q.optionA || "", optionB: q.optionB || "", optionC: q.optionC || "", optionD: q.optionD || "",
      correctOpt: q.correctOpt || "A", points: q.points,
    });
    setError(""); setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    const payload = { ...form, subjectId: Number(form.subjectId), points: Number(form.points) };
    try {
      const url = editQ ? `/api/teacher/questions/${editQ.id}` : "/api/teacher/questions";
      const method = editQ ? "PUT" : "POST";
      const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await res.json();
      if (!data.success) { setError(data.error || "Gagal"); return; }
      const saved = { ...data.data, subject: subjects.find(s => s.id === data.data.subjectId) };
      if (editQ) setQuestions(p => p.map(q => q.id === saved.id ? saved : q));
      else setQuestions(p => [saved, ...p]);
      setShowModal(false);
    } catch { setError("Server error"); }
    finally { setLoading(false); }
  }

  async function handleDelete(id: number) {
    if (!confirm("Hapus soal ini?")) return;
    const res = await fetch(`/api/teacher/questions/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) setQuestions(p => p.filter(q => q.id !== id));
  }

  return (
    <>
      {/* Filters + Add */}
      <div className="flex flex-wrap items-center gap-3 mb-5">
        <select className="input w-44" value={filterSubject} onChange={e => setFilterSubject(e.target.value)}>
          <option value="ALL">Semua Mapel</option>
          {subjects.map(s => <option key={s.id} value={String(s.id)}>{s.name}</option>)}
        </select>
        <select className="input w-44" value={filterType} onChange={e => setFilterType(e.target.value)}>
          <option value="ALL">Semua Tipe</option>
          <option value="MULTIPLE_CHOICE">Pilihan Ganda</option>
          <option value="ESSAY">Essay</option>
        </select>
        <span className="text-sm text-gray-400">{filtered.length} soal</span>
        <button className="btn btn-primary btn-sm ml-auto" onClick={openAdd}>+ Tambah Soal</button>
      </div>

      {/* Table */}
      <div className="table-wrapper">
        <table>
          <thead>
            <tr><th>#</th><th>Mapel</th><th>Tipe</th><th>Soal</th><th>Poin</th><th>Media</th><th>Aksi</th></tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={7} className="text-center text-gray-400 py-10">Belum ada soal</td></tr>
            )}
            {filtered.map((q, i) => (
              <tr key={q.id}>
                <td className="text-gray-400 text-xs">{i + 1}</td>
                <td><span className="badge badge-blue">{q.subject?.name || "–"}</span></td>
                <td><span className={`badge ${q.type === "MULTIPLE_CHOICE" ? "badge-purple" : "badge-yellow"}`}>
                  {q.type === "MULTIPLE_CHOICE" ? "PG" : "Essay"}
                </span></td>
                <td className="max-w-xs">
                  <p className="truncate text-sm">{q.body}</p>
                </td>
                <td className="font-mono text-sm">{q.points}</td>
                <td>
                  {(q.imageUrl || q.videoUrl) ? (
                    <span className="badge badge-green">{q.imageUrl ? "🖼️" : ""}{q.videoUrl ? "🎬" : ""}</span>
                  ) : <span className="text-gray-300">–</span>}
                </td>
                <td>
                  <div className="flex gap-1">
                    <button className="btn btn-ghost btn-sm" onClick={() => openEdit(q)}>✏️</button>
                    <button className="btn btn-ghost btn-sm text-red-500" onClick={() => handleDelete(q.id)}>🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6">
            <h3 className="text-lg font-bold mb-5">{editQ ? "Edit Soal" : "Tambah Soal"}</h3>
            {error && <div className="alert alert-error mb-4">{error}</div>}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Mata Pelajaran</label>
                  <select className="input" value={form.subjectId} onChange={e => setForm(p => ({...p, subjectId: e.target.value}))}>
                    {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Tipe Soal</label>
                  <select className="input" value={form.type} onChange={e => setForm(p => ({...p, type: e.target.value}))}>
                    <option value="MULTIPLE_CHOICE">Pilihan Ganda</option>
                    <option value="ESSAY">Essay</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="label">Pertanyaan / Soal</label>
                <textarea className="input min-h-24 resize-none" placeholder="Tulis soal di sini..."
                  value={form.body} onChange={e => setForm(p => ({...p, body: e.target.value}))} required />
              </div>

              {/* Multimedia */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">URL Gambar (opsional)</label>
                  <input className="input" placeholder="https://..." value={form.imageUrl}
                    onChange={e => setForm(p => ({...p, imageUrl: e.target.value}))} />
                </div>
                <div>
                  <label className="label">URL Video (opsional)</label>
                  <input className="input" placeholder="https://youtube.com/..." value={form.videoUrl}
                    onChange={e => setForm(p => ({...p, videoUrl: e.target.value}))} />
                </div>
              </div>

              {/* Multiple choice options */}
              {form.type === "MULTIPLE_CHOICE" && (
                <div className="space-y-3 p-4 bg-blue-50 rounded-xl">
                  <p className="text-sm font-semibold text-blue-800">Pilihan Jawaban</p>
                  {(["A", "B", "C", "D"] as const).map(opt => (
                    <div key={opt} className="flex items-center gap-2">
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input type="radio" name="correctOpt" value={opt} checked={form.correctOpt === opt}
                          onChange={() => setForm(p => ({...p, correctOpt: opt}))} />
                        <span className="font-bold w-5 text-blue-700">{opt}.</span>
                      </label>
                      <input className="input flex-1" placeholder={`Pilihan ${opt}`}
                        value={form[`option${opt}` as "optionA"]}
                        onChange={e => setForm(p => ({...p, [`option${opt}`]: e.target.value}))}
                        required />
                    </div>
                  ))}
                  <p className="text-xs text-blue-600">● = Jawaban benar</p>
                </div>
              )}

              <div>
                <label className="label">Poin</label>
                <input className="input w-24" type="number" min={1} max={100} value={form.points}
                  onChange={e => setForm(p => ({...p, points: Number(e.target.value)}))} />
              </div>

              <div className="flex gap-3 pt-2">
                <button type="button" className="btn btn-ghost flex-1" onClick={() => setShowModal(false)}>Batal</button>
                <button type="submit" className="btn btn-primary flex-1" disabled={loading}>
                  {loading ? "Menyimpan..." : "Simpan Soal"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
