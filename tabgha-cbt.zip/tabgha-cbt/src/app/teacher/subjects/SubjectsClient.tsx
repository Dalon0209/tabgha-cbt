"use client";
// src/app/teacher/subjects/SubjectsClient.tsx
import { useState } from "react";
import type { Subject } from "@/types";

export default function SubjectsClient({ initialSubjects }: { initialSubjects: Subject[] }) {
  const [subjects, setSubjects] = useState(initialSubjects);
  const [showModal, setShowModal] = useState(false);
  const [editSubject, setEditSubject] = useState<Subject | null>(null);
  const [form, setForm] = useState({ name: "", code: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function openAdd() { setEditSubject(null); setForm({ name: "", code: "" }); setError(""); setShowModal(true); }
  function openEdit(s: Subject) { setEditSubject(s); setForm({ name: s.name, code: s.code }); setError(""); setShowModal(true); }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    try {
      const url = editSubject ? `/api/teacher/subjects/${editSubject.id}` : "/api/teacher/subjects";
      const method = editSubject ? "PUT" : "POST";
      const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const data = await res.json();
      if (!data.success) { setError(data.error || "Gagal"); return; }
      if (editSubject) setSubjects(p => p.map(s => s.id === data.data.id ? { ...s, ...data.data } : s));
      else setSubjects(p => [...p, { ...data.data, _count: { questions: 0, exams: 0 } }]);
      setShowModal(false);
    } catch { setError("Server error"); }
    finally { setLoading(false); }
  }

  async function handleDelete(id: number) {
    if (!confirm("Hapus mata pelajaran ini? Semua soal terkait akan ikut terhapus.")) return;
    const res = await fetch(`/api/teacher/subjects/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) setSubjects(p => p.filter(s => s.id !== id));
  }

  return (
    <>
      <div className="flex items-center justify-between mb-5">
        <span className="text-sm text-gray-500">{subjects.length} mata pelajaran</span>
        <button className="btn btn-primary btn-sm" onClick={openAdd}>+ Tambah Mapel</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.length === 0 && (
          <div className="col-span-3 text-center py-16 text-gray-400">
            <div className="text-4xl mb-3">📚</div>
            <p>Belum ada mata pelajaran. Buat yang pertama!</p>
          </div>
        )}
        {subjects.map(s => (
          <div key={s.id} className="card hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="font-bold text-gray-900">{s.name}</h3>
                <span className="badge badge-blue mt-1">{s.code}</span>
              </div>
              <div className="flex gap-1">
                <button className="btn btn-ghost btn-sm" onClick={() => openEdit(s)}>✏️</button>
                <button className="btn btn-ghost btn-sm text-red-500" onClick={() => handleDelete(s.id)}>🗑️</button>
              </div>
            </div>
            <div className="flex gap-4 pt-3 border-t border-gray-100">
              <div className="text-center">
                <div className="font-bold text-gray-900">{s._count?.questions ?? 0}</div>
                <div className="text-xs text-gray-400">Soal</div>
              </div>
              <div className="text-center">
                <div className="font-bold text-gray-900">{s._count?.exams ?? 0}</div>
                <div className="text-xs text-gray-400">Ujian</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 p-6">
            <h3 className="text-lg font-bold mb-4">{editSubject ? "Edit Mata Pelajaran" : "Tambah Mata Pelajaran"}</h3>
            {error && <div className="alert alert-error mb-3">{error}</div>}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Nama Mata Pelajaran</label>
                <input className="input" placeholder="e.g. Matematika" value={form.name}
                  onChange={e => setForm(p => ({...p, name: e.target.value}))} required />
              </div>
              <div>
                <label className="label">Kode Mapel</label>
                <input className="input" placeholder="e.g. MTK" value={form.code}
                  onChange={e => setForm(p => ({...p, code: e.target.value.toUpperCase()}))} required />
              </div>
              <div className="flex gap-3 pt-1">
                <button type="button" className="btn btn-ghost flex-1" onClick={() => setShowModal(false)}>Batal</button>
                <button type="submit" className="btn btn-primary flex-1" disabled={loading}>
                  {loading ? "Menyimpan..." : "Simpan"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
