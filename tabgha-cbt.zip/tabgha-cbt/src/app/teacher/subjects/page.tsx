// src/app/teacher/subjects/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import SubjectsClient from "./SubjectsClient";

export default async function SubjectsPage() {
  const user = await getCurrentUser();
  const subjects = await prisma.subject.findMany({
    where: { creatorId: user!.userId },
    orderBy: { name: "asc" },
    include: { _count: { select: { questions: true, exams: true } } },
  });

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Mata Pelajaran</h1>
        <p className="text-gray-500 mt-1">Kelola mata pelajaran dan bank soal Anda.</p>
      </div>
      <SubjectsClient initialSubjects={subjects.map(s => ({
        id: s.id, name: s.name, code: s.code, creatorId: s.creatorId,
        _count: s._count,
      }))} />
    </div>
  );
}
