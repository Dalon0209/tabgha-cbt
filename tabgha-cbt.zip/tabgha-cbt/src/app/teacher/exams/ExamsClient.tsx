"use client";
// src/app/teacher/exams/ExamsClient.tsx
import { useState } from "react";
import type { Exam, Subject, Question } from "@/types";

const defaultForm = { title: "", subjectId: "", classRoom: "", duration: 60 };

export default function ExamsClient({
  subjects, initialExams, teacherId,
}: { subjects: Subject[]; initialExams: Exam[]; teacherId: number }) {
  const [exams, setExams] = useState(initialExams);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [activeExam, setActiveExam] = useState<Exam | null>(null);
  const [form, setForm] = useState({ ...defaultForm });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Question picker
  const [availableQuestions, setAvailableQuestions] = useState<Question[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault(); setLoading(true); setError("");
    try {
      const res = await fetch("/api/teacher/exams", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, subjectId: Number(form.subjectId), duration: Number(form.duration) }),
      });
      const data = await res.json();
      if (!data.success) { setError(data.error || "Gagal"); return; }
      setExams(p => [{ ...data.data, _count: { examQuestions: 0, examAttempts: 0 } }, ...p]);
      setShowCreateModal(false);
      setForm({ ...defaultForm });
    } catch { setError("Server error"); }
    finally { setLoading(false); }
  }

  async function openQuestionPicker(exam: Exam) {
    setActiveExam(exam);
    // Load available questions for subject
    const [qRes, selectedRes] = await Promise.all([
      fetch(`/api/teacher/questions?subjectId=${exam.subjectId}`),
      fetch(`/api/teacher/exams/${exam.id}/questions`),
    ]);
    const qData = await qRes.json();
    const selData = await selectedRes.json();
    setAvailableQuestions(qData.data || []);
    setSelectedIds(new Set((selData.data || []).map((q: Question) => q.id)));
    setShowQuestionModal(true);
  }

  async function saveQuestions() {
    if (!activeExam) return;
    setLoading(true);
    await fetch(`/api/teacher/exams/${activeExam.id}/questions`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questionIds: Array.from(selectedIds) }),
    });
    setExams(p => p.map(e => e.id === activeExam.id ? { ...e, _count: { ...e._count!, examQuestions: selectedIds.size } } : e));
    setShowQuestionModal(false);
    setLoading(false);
  }

  async function handlePublish(examId: number) {
    if (!confirm("Publikasikan ujian ini? Siswa akan bisa mengaksesnya dengan token.")) return;
    const res = await fetch(`/api/teacher/exams/${examId}/publish`, { method: "POST" });
    const data = await res.json();
    if (data.success) {
      setExams(p => p.map(e => e.id === examId ? { ...e, status: "PUBLISHED", token: data.data.token } : e));
    }
  }

  async function handleDelete(id: number) {
    if (!confirm("Hapus ujian ini?")) return;
    const res = await fetch(`/api/teacher/exams/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) setExams(p => p.filter(e => e.id !== id));
  }

  function toggleQuestion(id: number) {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  return (
    <>
      <div className="flex items-center justify-between mb-5">
        <span className="text-sm text-gray-500">{exams.length} ujian</span>
        <button className="btn btn-primary btn-sm" onClick={() => { setShowCreateModal(true); setError(""); }}>+ Buat Ujian Baru</button>
      </div>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr><th>Judul Ujian</th><th>Mapel</th><th>Kelas</th><th>Durasi</th><th>Soal</th><th>Peserta</th><th>Token</th><th>Status</th><th>Aksi</th></tr>
          </thead>
          <tbody>
            {exams.length === 0 && (
              <tr><td colSpan={9} className="text-center text-gray-400 py-10">Belum ada ujian</td></tr>
            )}
            {exams.map(exam => (
              <tr key={exam.id}>
                <td className="font-medium max-w-48 truncate">{exam.title}</td>
                <td>{exam.subject?.name}</td>
                <td>{exam.classRoom}</td>
                <td>{exam.duration} mnt</td>
                <td>{exam._count?.examQuestions ?? 0}</td>
                <td>{exam._count?.examAttempts ?? 0}</td>
                <td>
                  {exam.token
                    ? <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">{exam.token}</code>
                    : <span className="text-gray-300">–</span>}
                </td>
                <td>
                  <span className={`badge ${exam.status === "PUBLISHED" ? "badge-green" : "badge-gray"}`}>
                    {exam.status === "PUBLISHED" ? "Aktif" : "Draft"}
                  </span>
                </td>
                <td>
                  <div className="flex gap-1 flex-wrap">
                    <button className="btn btn-ghost btn-sm" title="Pilih Soal" onClick={() => openQuestionPicker(exam)}>📝</button>
                    {exam.status === "DRAFT" && (
                      <button className="btn btn-ghost btn-sm text-green-600" title="Publikasikan" onClick={() => handlePublish(exam.id)}>▶</button>
                    )}
                    <button className="btn btn-ghost btn-sm text-red-500" title="Hapus" onClick={() => handleDelete(exam.id)}>🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Create Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6">
            <h3 className="text-lg font-bold mb-5">Buat Ujian Baru</h3>
            {error && <div className="alert alert-error mb-4">{error}</div>}
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="label">Judul Ujian</label>
                <input className="input" placeholder="e.g. UH 1 Matematika Bab 1" value={form.title}
                  onChange={e => setForm(p => ({...p, title: e.target.value}))} required />
              </div>
              <div>
                <label className="label">Mata Pelajaran</label>
                <select className="input" value={form.subjectId} onChange={e => setForm(p => ({...p, subjectId: e.target.value}))} required>
                  <option value="">Pilih mapel...</option>
                  {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Kelas Target</label>
                  <input className="input" placeholder="e.g. 7A" value={form.classRoom}
                    onChange={e => setForm(p => ({...p, classRoom: e.target.value}))} required />
                </div>
                <div>
                  <label className="label">Durasi (menit)</label>
                  <input className="input" type="number" min={5} max={300} value={form.duration}
                    onChange={e => setForm(p => ({...p, duration: Number(e.target.value)}))} required />
                </div>
              </div>
              <div className="flex gap-3 pt-1">
                <button type="button" className="btn btn-ghost flex-1" onClick={() => setShowCreateModal(false)}>Batal</button>
                <button type="submit" className="btn btn-primary flex-1" disabled={loading}>
                  {loading ? "Membuat..." : "Buat Ujian"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Question Picker Modal */}
      {showQuestionModal && activeExam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col">
            <div className="p-5 border-b">
              <h3 className="text-lg font-bold">Pilih Soal untuk &ldquo;{activeExam.title}&rdquo;</h3>
              <p className="text-sm text-gray-500 mt-0.5">{selectedIds.size} soal dipilih</p>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-2">
              {availableQuestions.length === 0 && (
                <p className="text-center text-gray-400 py-8">Tidak ada soal. Buat soal di Bank Soal dahulu.</p>
              )}
              {availableQuestions.map((q, i) => (
                <label key={q.id} className={`flex items-start gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all ${selectedIds.has(q.id) ? "border-blue-500 bg-blue-50" : "border-gray-100 hover:border-gray-200"}`}>
                  <input type="checkbox" className="mt-0.5" checked={selectedIds.has(q.id)}
                    onChange={() => toggleQuestion(q.id)} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs text-gray-400">#{i + 1}</span>
                      <span className={`badge ${q.type === "MULTIPLE_CHOICE" ? "badge-purple" : "badge-yellow"} text-xs`}>
                        {q.type === "MULTIPLE_CHOICE" ? "PG" : "Essay"}
                      </span>
                      <span className="text-xs text-gray-400">{q.points} poin</span>
                    </div>
                    <p className="text-sm truncate">{q.body}</p>
                  </div>
                </label>
              ))}
            </div>
            <div className="p-4 border-t flex gap-3">
              <button className="btn btn-ghost flex-1" onClick={() => setShowQuestionModal(false)}>Batal</button>
              <button className="btn btn-primary flex-1" onClick={saveQuestions} disabled={loading}>
                {loading ? "Menyimpan..." : `Simpan (${selectedIds.size} soal)`}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
