// src/app/teacher/exams/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import ExamsClient from "./ExamsClient";

export default async function TeacherExamsPage() {
  const user = await getCurrentUser();
  const [subjects, exams] = await Promise.all([
    prisma.subject.findMany({ where: { creatorId: user!.userId }, orderBy: { name: "asc" } }),
    prisma.exam.findMany({
      where: { creatorId: user!.userId },
      include: {
        subject: { select: { id: true, name: true } },
        _count: { select: { examQuestions: true, examAttempts: true } },
      },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Kelola Ujian</h1>
        <p className="text-gray-500 mt-1">Buat, atur soal, dan publikasikan ujian untuk siswa.</p>
      </div>
      <ExamsClient
        subjects={subjects}
        initialExams={exams.map(e => ({
          ...e,
          token: e.token ?? undefined,
          startTime: e.startTime?.toISOString() ?? undefined,
          endTime: e.endTime?.toISOString() ?? undefined,
          createdAt: e.createdAt.toISOString(),
        }))}
        teacherId={user!.userId}
      />
    </div>
  );
}
