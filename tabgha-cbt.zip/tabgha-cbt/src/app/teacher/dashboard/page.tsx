// src/app/teacher/dashboard/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export default async function TeacherDashboardPage() {
  const user = await getCurrentUser();
  const teacherId = user!.userId;

  const [subjectCount, questionCount, examCount, publishedExams] = await Promise.all([
    prisma.subject.count({ where: { creatorId: teacherId } }),
    prisma.question.count({ where: { subject: { creatorId: teacherId } } }),
    prisma.exam.count({ where: { creatorId: teacherId } }),
    prisma.exam.count({ where: { creatorId: teacherId, status: "PUBLISHED" } }),
  ]);

  const recentExams = await prisma.exam.findMany({
    where: { creatorId: teacherId },
    take: 5,
    orderBy: { createdAt: "desc" },
    include: {
      subject: { select: { name: true } },
      _count: { select: { examAttempts: true, examQuestions: true } },
    },
  });

  const stats = [
    { label: "Mata Pelajaran", value: subjectCount, icon: "📚", color: "#0891b2" },
    { label: "Total Soal", value: questionCount, icon: "❓", color: "#7c3aed" },
    { label: "Total Ujian", value: examCount, icon: "📝", color: "#d97706" },
    { label: "Ujian Aktif", value: publishedExams, icon: "✅", color: "#16a34a" },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Guru</h1>
        <p className="text-gray-500 mt-1">Selamat datang, <strong>{user?.name}</strong></p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map(s => (
          <div key={s.label} className="stat-card">
            <div className="text-2xl">{s.icon}</div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-gray-900">Ujian Terbaru Saya</h2>
          <a href="/teacher/exams" className="text-sm text-blue-600 hover:underline">Kelola ujian →</a>
        </div>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr><th>Judul</th><th>Mapel</th><th>Kelas</th><th>Soal</th><th>Peserta</th><th>Status</th></tr>
            </thead>
            <tbody>
              {recentExams.length === 0 && (
                <tr><td colSpan={6} className="text-center text-gray-400 py-8">Belum ada ujian. <a href="/teacher/exams" className="text-blue-600 underline">Buat ujian baru</a></td></tr>
              )}
              {recentExams.map(exam => (
                <tr key={exam.id}>
                  <td className="font-medium">{exam.title}</td>
                  <td>{exam.subject.name}</td>
                  <td>{exam.classRoom}</td>
                  <td>{exam._count.examQuestions}</td>
                  <td>{exam._count.examAttempts}</td>
                  <td><span className={`badge ${exam.status === "PUBLISHED" ? "badge-green" : "badge-gray"}`}>
                    {exam.status === "PUBLISHED" ? "Aktif" : "Draft"}
                  </span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
