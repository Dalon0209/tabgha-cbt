"use client";
// src/app/teacher/results/ResultsClient.tsx
import { useState } from "react";
import type { ExamAttempt } from "@/types";

interface ExamSummary {
  id: number; title: string; classRoom: string;
  subject: { name: string };
  _count: { examAttempts: number };
}

export default function ResultsClient({ exams }: { exams: ExamSummary[] }) {
  const [selectedExam, setSelectedExam] = useState<ExamSummary | null>(null);
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);

  async function loadResults(exam: ExamSummary) {
    setSelectedExam(exam); setLoading(true);
    const res = await fetch(`/api/teacher/exams/${exam.id}/results`);
    const data = await res.json();
    setAttempts(data.data || []);
    setLoading(false);
  }

  async function exportExcel() {
    if (!selectedExam) return;
    setExporting(true);
    const res = await fetch(`/api/teacher/exams/${selectedExam.id}/export?format=excel`);
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hasil-ujian-${selectedExam.title.replace(/\s+/g, "_")}.xlsx`;
    a.click();
    URL.revokeObjectURL(url);
    setExporting(false);
  }

  async function exportPdf() {
    if (!selectedExam) return;
    setExporting(true);
    const res = await fetch(`/api/teacher/exams/${selectedExam.id}/export?format=pdf`);
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hasil-ujian-${selectedExam.title.replace(/\s+/g, "_")}.pdf`;
    a.click();
    URL.revokeObjectURL(url);
    setExporting(false);
  }

  const avg = attempts.length > 0
    ? (attempts.reduce((s, a) => s + (a.score || 0), 0) / attempts.length).toFixed(1)
    : "–";
  const passing = attempts.filter(a => (a.score || 0) >= 75).length;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Exam list */}
      <div className="card">
        <h2 className="font-bold mb-3">Pilih Ujian</h2>
        <div className="space-y-2">
          {exams.length === 0 && <p className="text-gray-400 text-sm">Belum ada ujian aktif</p>}
          {exams.map(e => (
            <button key={e.id}
              className={`w-full text-left p-3 rounded-xl border-2 transition-all ${selectedExam?.id === e.id ? "border-blue-500 bg-blue-50" : "border-gray-100 hover:border-gray-200"}`}
              onClick={() => loadResults(e)}>
              <div className="font-medium text-sm">{e.title}</div>
              <div className="text-xs text-gray-400 mt-0.5">{e.subject.name} · Kelas {e.classRoom} · {e._count.examAttempts} peserta</div>
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="lg:col-span-2">
        {!selectedExam && (
          <div className="card flex items-center justify-center h-48">
            <p className="text-gray-400">Pilih ujian untuk melihat hasil</p>
          </div>
        )}
        {selectedExam && (
          <>
            {/* Stats row */}
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="stat-card">
                <div className="stat-value text-blue-600">{attempts.length}</div>
                <div className="stat-label">Peserta</div>
              </div>
              <div className="stat-card">
                <div className="stat-value text-amber-600">{avg}</div>
                <div className="stat-label">Rata-rata</div>
              </div>
              <div className="stat-card">
                <div className="stat-value text-green-600">{passing}</div>
                <div className="stat-label">Lulus (≥75)</div>
              </div>
            </div>

            <div className="card">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">{selectedExam.title}</h3>
                <div className="flex gap-2">
                  <button className="btn btn-outline btn-sm" onClick={exportExcel} disabled={exporting}>📊 Excel</button>
                  <button className="btn btn-outline btn-sm" onClick={exportPdf} disabled={exporting}>📄 PDF</button>
                </div>
              </div>

              {loading && <div className="text-center py-8 text-gray-400">Memuat...</div>}
              {!loading && (
                <div className="table-wrapper">
                  <table>
                    <thead>
                      <tr><th>#</th><th>Nama Siswa</th><th>Kelas</th><th>Nilai</th><th>Status</th><th>Kecurangan</th></tr>
                    </thead>
                    <tbody>
                      {attempts.length === 0 && (
                        <tr><td colSpan={6} className="text-center text-gray-400 py-8">Belum ada yang mengerjakan</td></tr>
                      )}
                      {attempts.map((a, i) => (
                        <tr key={a.id}>
                          <td className="text-gray-400 text-xs">{i + 1}</td>
                          <td className="font-medium">{a.student?.name}</td>
                          <td>{a.student?.classRoom}</td>
                          <td>
                            <span className={`font-bold ${(a.score || 0) >= 75 ? "text-green-600" : "text-red-600"}`}>
                              {a.score?.toFixed(1) ?? "–"}
                            </span>
                          </td>
                          <td>
                            <span className={`badge ${a.isSubmitted ? "badge-green" : "badge-yellow"}`}>
                              {a.isSubmitted ? "Selesai" : "Belum Submit"}
                            </span>
                          </td>
                          <td>
                            {!a.isValid || (a.cheatLogs && a.cheatLogs.length > 0)
                              ? <span className="badge badge-red">⚠️ {a.cheatLogs?.length || 0} log</span>
                              : <span className="badge badge-green">Bersih</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
