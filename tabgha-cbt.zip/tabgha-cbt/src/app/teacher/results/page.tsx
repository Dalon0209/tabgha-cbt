// src/app/teacher/results/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import ResultsClient from "./ResultsClient";

export default async function ResultsPage() {
  const user = await getCurrentUser();
  const exams = await prisma.exam.findMany({
    where: { creatorId: user!.userId, status: "PUBLISHED" },
    include: {
      subject: { select: { name: true } },
      _count: { select: { examAttempts: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Hasil & Laporan</h1>
        <p className="text-gray-500 mt-1">Lihat hasil ujian dan ekspor ke Excel/PDF.</p>
      </div>
      <ResultsClient exams={exams.map(e => ({
        id: e.id, title: e.title, subject: e.subject,
        _count: e._count, classRoom: e.classRoom,
      }))} />
    </div>
  );
}
