"use client";
// src/app/login/page.tsx
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ username: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!data.success) { setError(data.error || "Login gagal"); return; }
      const { role } = data.data.user;
      if (role === "ADMIN")   router.push("/admin/dashboard");
      else if (role === "TEACHER") router.push("/teacher/dashboard");
      else router.push("/student/dashboard");
    } catch {
      setError("Terjadi kesalahan. Coba lagi.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center" style={{
      background: "linear-gradient(135deg, #1e3a8a 0%, #2563eb 50%, #3b82f6 100%)"
    }}>
      <div className="w-full max-w-sm px-4">
        {/* Logo & Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white shadow-lg mb-4">
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
              <rect x="2" y="14" width="14" height="20" rx="2" fill="#2563eb"/>
              <rect x="20" y="6" width="14" height="28" rx="2" fill="#16a34a"/>
              <rect x="8" y="2" width="20" height="10" rx="2" fill="#dc2626"/>
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-white">Tabgha CBT</h1>
          <p className="text-blue-200 text-sm mt-1">SMP Tabgha – Sistem Ujian Online</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6 text-center">Masuk</h2>

          {error && (
            <div className="alert alert-error mb-4">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Username</label>
              <input
                className="input"
                placeholder="Masukkan username"
                value={form.username}
                onChange={e => setForm(p => ({ ...p, username: e.target.value }))}
                required
                autoFocus
              />
            </div>
            <div>
              <label className="label">Password</label>
              <input
                className="input"
                type="password"
                placeholder="Masukkan password"
                value={form.password}
                onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                required
              />
            </div>
            <button
              type="submit"
              className="btn btn-primary w-full btn-lg mt-2"
              disabled={loading}
            >
              {loading ? "Memproses..." : "Login"}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-gray-100 text-center">
            <p className="text-xs text-gray-400">
              Hubungi administrator jika lupa password
            </p>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-blue-200 text-xs mt-6">
          © 2024 Tabgha Academic · Computer-Based Test System
        </p>
      </div>
    </div>
  );
}
