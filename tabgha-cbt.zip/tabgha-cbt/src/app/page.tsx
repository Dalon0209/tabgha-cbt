// src/app/page.tsx
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export default async function RootPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  switch (user.role) {
    case "ADMIN":   redirect("/admin/dashboard");
    case "TEACHER": redirect("/teacher/dashboard");
    case "STUDENT": redirect("/student/dashboard");
    default:        redirect("/login");
  }
}
