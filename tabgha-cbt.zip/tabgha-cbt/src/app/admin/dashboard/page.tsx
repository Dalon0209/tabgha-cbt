// src/app/admin/dashboard/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export default async function AdminDashboardPage() {
  const user = await getCurrentUser();
  const [userCount, teacherCount, studentCount, examCount, activeExams, setting] =
    await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { role: "TEACHER" } }),
      prisma.user.count({ where: { role: "STUDENT" } }),
      prisma.exam.count(),
      prisma.exam.count({ where: { status: "PUBLISHED" } }),
      prisma.systemSetting.findFirst(),
    ]);

  const recentExams = await prisma.exam.findMany({
    take: 5,
    orderBy: { createdAt: "desc" },
    include: { creator: { select: { name: true } }, subject: { select: { name: true } } },
  });

  const stats = [
    { label: "Total Pengguna", value: userCount, color: "#7c3aed", icon: "👥" },
    { label: "Guru", value: teacherCount, color: "#0891b2", icon: "👨‍🏫" },
    { label: "Siswa", value: studentCount, color: "#2563eb", icon: "🎓" },
    { label: "Total Ujian", value: examCount, color: "#d97706", icon: "📋" },
    { label: "Ujian Aktif", value: activeExams, color: "#16a34a", icon: "✅" },
  ];

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Administrator</h1>
        <p className="text-gray-500 mt-1">
          Selamat datang, <strong>{user?.name}</strong> · {setting?.schoolName} · {setting?.activeTerm}
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        {stats.map(s => (
          <div key={s.label} className="stat-card">
            <div className="text-2xl">{s.icon}</div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Recent Exams */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-gray-900">Ujian Terbaru</h2>
          <a href="/admin/exams" className="text-sm text-blue-600 hover:underline">Lihat semua →</a>
        </div>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Judul Ujian</th>
                <th>Mata Pelajaran</th>
                <th>Kelas</th>
                <th>Guru</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {recentExams.length === 0 && (
                <tr><td colSpan={5} className="text-center text-gray-400 py-8">Belum ada ujian</td></tr>
              )}
              {recentExams.map(exam => (
                <tr key={exam.id}>
                  <td className="font-medium">{exam.title}</td>
                  <td>{exam.subject.name}</td>
                  <td>{exam.classRoom}</td>
                  <td>{exam.creator.name}</td>
                  <td>
                    <span className={`badge ${exam.status === "PUBLISHED" ? "badge-green" : "badge-gray"}`}>
                      {exam.status === "PUBLISHED" ? "Aktif" : "Draft"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
