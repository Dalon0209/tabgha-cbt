// src/app/admin/reports/page.tsx
import { prisma } from "@/lib/prisma";

export default async function AdminReportsPage() {
  const [totalUsers, totalStudents, totalTeachers, totalExams, totalAttempts, totalCheatLogs] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { role: "STUDENT" } }),
    prisma.user.count({ where: { role: "TEACHER" } }),
    prisma.exam.count(),
    prisma.examAttempt.count({ where: { isSubmitted: true } }),
    prisma.cheatLog.count(),
  ]);

  const avgScore = await prisma.examAttempt.aggregate({
    where: { isSubmitted: true, score: { not: null } },
    _avg: { score: true },
  });

  const topExams = await prisma.exam.findMany({
    where: { status: "PUBLISHED" },
    include: {
      subject: { select: { name: true } },
      creator: { select: { name: true } },
      _count: { select: { examAttempts: true } },
    },
    orderBy: { examAttempts: { _count: "desc" } },
    take: 10,
  });

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Laporan Sistem</h1>
        <p className="text-gray-500 mt-1">Statistik keseluruhan platform Tabgha CBT.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        {[
          { label: "Total Pengguna", value: totalUsers, color: "#7c3aed" },
          { label: "Siswa", value: totalStudents, color: "#2563eb" },
          { label: "Guru", value: totalTeachers, color: "#0891b2" },
          { label: "Total Ujian", value: totalExams, color: "#d97706" },
          { label: "Ujian Dikerjakan", value: totalAttempts, color: "#16a34a" },
          { label: "Log Kecurangan", value: totalCheatLogs, color: "#dc2626" },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card mb-6">
        <div className="flex items-center justify-between mb-1">
          <h2 className="font-bold">Rata-rata Nilai Seluruh Ujian</h2>
        </div>
        <div className="text-5xl font-black text-blue-600 mt-2">
          {avgScore._avg.score?.toFixed(1) ?? "–"}
        </div>
        <div className="text-sm text-gray-400">dari 100</div>
      </div>

      <div className="card">
        <h2 className="font-bold mb-4">Ujian Paling Banyak Diikuti</h2>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr><th>#</th><th>Judul Ujian</th><th>Mapel</th><th>Guru</th><th>Peserta</th></tr>
            </thead>
            <tbody>
              {topExams.map((e, i) => (
                <tr key={e.id}>
                  <td className="text-gray-400 text-xs">{i + 1}</td>
                  <td className="font-medium">{e.title}</td>
                  <td>{e.subject.name}</td>
                  <td>{e.creator.name}</td>
                  <td className="font-bold text-blue-600">{e._count.examAttempts}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
