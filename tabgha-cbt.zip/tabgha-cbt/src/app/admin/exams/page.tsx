// src/app/admin/exams/page.tsx
import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function AdminExamsPage() {
  const exams = await prisma.exam.findMany({
    include: {
      creator: { select: { name: true } },
      subject: { select: { name: true } },
      _count: { select: { examAttempts: true, examQuestions: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Monitor Semua Ujian</h1>
        <p className="text-gray-500 mt-1">Pantau seluruh ujian yang dibuat oleh guru.</p>
      </div>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr><th>Judul</th><th>Mapel</th><th>Guru</th><th>Kelas</th><th>Soal</th><th>Peserta</th><th>Token</th><th>Status</th></tr>
          </thead>
          <tbody>
            {exams.length === 0 && (
              <tr><td colSpan={8} className="text-center text-gray-400 py-10">Belum ada ujian</td></tr>
            )}
            {exams.map(e => (
              <tr key={e.id}>
                <td className="font-medium max-w-48 truncate">{e.title}</td>
                <td>{e.subject.name}</td>
                <td>{e.creator.name}</td>
                <td>{e.classRoom}</td>
                <td>{e._count.examQuestions}</td>
                <td>{e._count.examAttempts}</td>
                <td>
                  {e.token
                    ? <code className="text-xs bg-gray-100 px-2 py-1 rounded font-mono">{e.token}</code>
                    : <span className="text-gray-300">–</span>}
                </td>
                <td>
                  <span className={`badge ${e.status === "PUBLISHED" ? "badge-green" : "badge-gray"}`}>
                    {e.status === "PUBLISHED" ? "Aktif" : "Draft"}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
