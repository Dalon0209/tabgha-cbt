// src/app/admin/settings/page.tsx
import { prisma } from "@/lib/prisma";
import SettingsClient from "./SettingsClient";

export default async function SettingsPage() {
  let setting = await prisma.systemSetting.findFirst();
  if (!setting) {
    setting = await prisma.systemSetting.create({
      data: { id: 1, schoolName: "SMP Tabgha", activeTerm: "Semester 1 2024/2025", schoolLevel: "SMP" },
    });
  }
  return (
    <div className="p-8 max-w-2xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Pengaturan Sistem</h1>
        <p className="text-gray-500 mt-1">Konfigurasi global sekolah dan semester aktif.</p>
      </div>
      <SettingsClient setting={{ ...setting }} />
    </div>
  );
}
