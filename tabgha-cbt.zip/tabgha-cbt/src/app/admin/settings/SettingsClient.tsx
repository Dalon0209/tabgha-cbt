"use client";
// src/app/admin/settings/SettingsClient.tsx
import { useState } from "react";
import type { SystemSetting } from "@/types";

export default function SettingsClient({ setting }: { setting: SystemSetting }) {
  const [form, setForm] = useState({ schoolName: setting.schoolName, activeTerm: setting.activeTerm, schoolLevel: setting.schoolLevel });
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setStatus("");
    const res = await fetch("/api/admin/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const data = await res.json();
    setStatus(data.success ? "✓ Pengaturan berhasil disimpan" : "✗ Gagal menyimpan");
    setLoading(false);
  }

  return (
    <div className="card">
      {status && <div className={`alert ${status.startsWith("✓") ? "alert-success" : "alert-error"} mb-4`}>{status}</div>}
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="label">Nama Sekolah</label>
          <input className="input" value={form.schoolName} onChange={e => setForm(p => ({...p, schoolName: e.target.value}))} required />
        </div>
        <div>
          <label className="label">Semester/Tahun Ajaran Aktif</label>
          <input className="input" placeholder="e.g. Semester 1 2024/2025" value={form.activeTerm}
            onChange={e => setForm(p => ({...p, activeTerm: e.target.value}))} required />
        </div>
        <div>
          <label className="label">Jenjang Sekolah</label>
          <select className="input" value={form.schoolLevel} onChange={e => setForm(p => ({...p, schoolLevel: e.target.value}))}>
            <option value="SD">SD</option>
            <option value="SMP">SMP</option>
            <option value="SMA">SMA</option>
            <option value="SMK">SMK</option>
          </select>
        </div>
        <button type="submit" className="btn btn-primary" disabled={loading}>
          {loading ? "Menyimpan..." : "Simpan Pengaturan"}
        </button>
      </form>
    </div>
  );
}
