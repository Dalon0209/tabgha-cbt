"use client";
// src/app/admin/users/UsersClient.tsx
import { useState, useRef } from "react";
import type { User } from "@/types";

const ROLE_LABELS: Record<string, string> = { ADMIN: "Admin", TEACHER: "Guru", STUDENT: "Siswa" };
const ROLE_BADGES: Record<string, string> = { ADMIN: "badge-purple", TEACHER: "badge-blue", STUDENT: "badge-green" };

export default function UsersClient({ initialUsers }: { initialUsers: User[] }) {
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [showModal, setShowModal] = useState(false);
  const [editUser, setEditUser] = useState<User | null>(null);
  const [form, setForm] = useState({ username: "", password: "", name: "", role: "STUDENT", classRoom: "" });
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState("ALL");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [csvStatus, setCsvStatus] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const filtered = users.filter(u => {
    const matchRole = filterRole === "ALL" || u.role === filterRole;
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.username.toLowerCase().includes(search.toLowerCase());
    return matchRole && matchSearch;
  });

  function openAdd() {
    setEditUser(null);
    setForm({ username: "", password: "", name: "", role: "STUDENT", classRoom: "" });
    setError("");
    setShowModal(true);
  }

  function openEdit(u: User) {
    setEditUser(u);
    setForm({ username: u.username, password: "", name: u.name, role: u.role, classRoom: u.classRoom || "" });
    setError("");
    setShowModal(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError("");
    try {
      const url = editUser ? `/api/admin/users/${editUser.id}` : "/api/admin/users";
      const method = editUser ? "PUT" : "POST";
      const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const data = await res.json();
      if (!data.success) { setError(data.error || "Gagal menyimpan"); return; }
      const saved = data.data;
      if (editUser) setUsers(p => p.map(u => u.id === saved.id ? saved : u));
      else setUsers(p => [...p, saved]);
      setShowModal(false);
    } catch { setError("Server error"); }
    finally { setLoading(false); }
  }

  async function handleDelete(id: number) {
    if (!confirm("Hapus pengguna ini?")) return;
    const res = await fetch(`/api/admin/users/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (data.success) setUsers(p => p.filter(u => u.id !== id));
  }

  async function handleCsvImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setCsvStatus("Mengimpor...");
    const text = await file.text();
    const res = await fetch("/api/admin/users/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ csv: text }),
    });
    const data = await res.json();
    if (data.success) {
      setCsvStatus(`✓ ${data.data.imported} pengguna berhasil diimpor`);
      // Refresh
      const usersRes = await fetch("/api/admin/users");
      const usersData = await usersRes.json();
      if (usersData.success) setUsers(usersData.data);
    } else {
      setCsvStatus(`✗ ${data.error}`);
    }
    if (fileRef.current) fileRef.current.value = "";
  }

  return (
    <>
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3 mb-5">
        <input className="input w-56" placeholder="Cari nama / username..." value={search}
          onChange={e => setSearch(e.target.value)} />
        <select className="input w-40" value={filterRole} onChange={e => setFilterRole(e.target.value)}>
          <option value="ALL">Semua Role</option>
          <option value="ADMIN">Admin</option>
          <option value="TEACHER">Guru</option>
          <option value="STUDENT">Siswa</option>
        </select>
        <div className="ml-auto flex items-center gap-2">
          {csvStatus && <span className="text-sm text-gray-500">{csvStatus}</span>}
          <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleCsvImport} />
          <button className="btn btn-outline btn-sm" onClick={() => fileRef.current?.click()}>
            📥 Import CSV
          </button>
          <button className="btn btn-primary btn-sm" onClick={openAdd}>+ Tambah Pengguna</button>
        </div>
      </div>

      {/* CSV Format hint */}
      <p className="text-xs text-gray-400 mb-4">
        Format CSV: <code>username,password,name,role,classRoom</code> (role: ADMIN/TEACHER/STUDENT)
      </p>

      {/* Table */}
      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>#</th><th>Nama</th><th>Username</th><th>Role</th><th>Kelas</th><th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="text-center text-gray-400 py-10">Tidak ada data</td></tr>
            )}
            {filtered.map((u, i) => (
              <tr key={u.id}>
                <td className="text-gray-400 text-xs">{i + 1}</td>
                <td className="font-medium">{u.name}</td>
                <td className="text-gray-500 font-mono text-sm">{u.username}</td>
                <td><span className={`badge ${ROLE_BADGES[u.role]}`}>{ROLE_LABELS[u.role]}</span></td>
                <td>{u.classRoom || <span className="text-gray-300">–</span>}</td>
                <td>
                  <div className="flex gap-2">
                    <button className="btn btn-ghost btn-sm" onClick={() => openEdit(u)}>✏️</button>
                    <button className="btn btn-ghost btn-sm text-red-500" onClick={() => handleDelete(u.id)}>🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 p-6">
            <h3 className="text-lg font-bold mb-5">{editUser ? "Edit Pengguna" : "Tambah Pengguna"}</h3>
            {error && <div className="alert alert-error mb-4">{error}</div>}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Nama Lengkap</label>
                <input className="input" value={form.name} onChange={e => setForm(p => ({...p, name: e.target.value}))} required />
              </div>
              <div>
                <label className="label">Username</label>
                <input className="input" value={form.username} onChange={e => setForm(p => ({...p, username: e.target.value}))} required />
              </div>
              <div>
                <label className="label">{editUser ? "Password Baru (kosongkan jika tidak diubah)" : "Password"}</label>
                <input className="input" type="password" value={form.password}
                  onChange={e => setForm(p => ({...p, password: e.target.value}))}
                  required={!editUser} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Role</label>
                  <select className="input" value={form.role} onChange={e => setForm(p => ({...p, role: e.target.value}))}>
                    <option value="STUDENT">Siswa</option>
                    <option value="TEACHER">Guru</option>
                    <option value="ADMIN">Admin</option>
                  </select>
                </div>
                {form.role === "STUDENT" && (
                  <div>
                    <label className="label">Kelas</label>
                    <input className="input" placeholder="e.g. 7A" value={form.classRoom}
                      onChange={e => setForm(p => ({...p, classRoom: e.target.value}))} />
                  </div>
                )}
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" className="btn btn-ghost flex-1" onClick={() => setShowModal(false)}>Batal</button>
                <button type="submit" className="btn btn-primary flex-1" disabled={loading}>
                  {loading ? "Menyimpan..." : "Simpan"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
