// src/app/admin/users/page.tsx
import { prisma } from "@/lib/prisma";
import UsersClient from "./UsersClient";

export default async function AdminUsersPage() {
  const users = await prisma.user.findMany({
    orderBy: [{ role: "asc" }, { name: "asc" }],
    select: { id: true, username: true, name: true, role: true, classRoom: true, createdAt: true },
  });

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Manajemen Pengguna</h1>
        <p className="text-gray-500 mt-1">Kelola admin, guru, dan siswa. Import massal via CSV.</p>
      </div>
      <UsersClient initialUsers={users.map(u => ({ ...u, createdAt: u.createdAt.toISOString() }))} />
    </div>
  );
}
