"use client";
// src/app/student/exam/[attemptId]/page.tsx
import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter, useParams } from "next/navigation";
import type { Question, ExamAttempt, Exam } from "@/types";

interface ExamData {
  attempt: ExamAttempt;
  exam: Exam & { questions: Question[] };
}

export default function ExamTakingPage() {
  const router = useRouter();
  const params = useParams();
  const attemptId = Number(params.attemptId);

  const [data, setData] = useState<ExamData | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [currentIdx, setCurrentIdx] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [cheatCount, setCheatCount] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hasFetched = useRef(false);

  // ── Load exam data ────────────────────────────────────────────────────────
  useEffect(() => {
    if (hasFetched.current) return;
    hasFetched.current = true;

    fetch(`/api/student/exam/${attemptId}`)
      .then(r => r.json())
      .then(d => {
        if (!d.success) { router.push("/student/dashboard"); return; }
        setData(d.data);
        setAnswers(d.data.attempt.answers || {});
        // Calculate remaining time
        const elapsed = Math.floor((Date.now() - new Date(d.data.attempt.startedAt).getTime()) / 1000);
        const totalSecs = d.data.exam.duration * 60;
        setTimeLeft(Math.max(0, totalSecs - elapsed));
        setLoading(false);
      })
      .catch(() => router.push("/student/dashboard"));
  }, [attemptId, router]);

  // ── Countdown timer ───────────────────────────────────────────────────────
  useEffect(() => {
    if (!data || timeLeft <= 0) return;
    intervalRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(intervalRef.current!);
          handleSubmit(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(intervalRef.current!);
  }, [data]); // eslint-disable-line

  // ── Anti-cheat: detect tab switch, minimize, blur ─────────────────────────
  const logCheat = useCallback(async (type: string) => {
    setCheatCount(p => p + 1);
    await fetch(`/api/student/exam/${attemptId}/cheat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type }),
    });
  }, [attemptId]);

  useEffect(() => {
    const onVisibilityChange = () => {
      if (document.hidden) logCheat("TAB_SWITCH");
    };
    const onBlur = () => logCheat("BLUR_FOCUS");

    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("blur", onBlur);

    // Prevent right-click
    const preventContextMenu = (e: MouseEvent) => e.preventDefault();
    document.addEventListener("contextmenu", preventContextMenu);

    return () => {
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("blur", onBlur);
      document.removeEventListener("contextmenu", preventContextMenu);
    };
  }, [logCheat]);

  // ── Auto-save answers ─────────────────────────────────────────────────────
  const saveAnswers = useCallback(async (newAnswers: Record<number, string>) => {
    await fetch(`/api/student/exam/${attemptId}/answer`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ answers: newAnswers }),
    });
  }, [attemptId]);

  function handleAnswer(questionId: number, value: string) {
    const next = { ...answers, [questionId]: value };
    setAnswers(next);
    saveAnswers(next);
  }

  // ── Submit ────────────────────────────────────────────────────────────────
  async function handleSubmit(auto = false) {
    if (submitting) return;
    setSubmitting(true);
    setShowConfirm(false);
    clearInterval(intervalRef.current!);

    try {
      await fetch(`/api/student/exam/${attemptId}/submit`, { method: "POST" });
      router.push(`/student/exam/${attemptId}/result`);
    } catch {
      setSubmitting(false);
    }
  }

  // ── Timer formatting ───────────────────────────────────────────────────────
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const timerColor = timeLeft < 300 ? "#dc2626" : timeLeft < 600 ? "#d97706" : "#16a34a";

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="text-4xl mb-4">⏳</div>
          <p className="text-gray-500">Memuat ujian...</p>
        </div>
      </div>
    );
  }

  if (!data) return null;

  const { exam } = data;
  const questions = exam.questions;
  const currentQ = questions[currentIdx];
  const answered = Object.keys(answers).length;

  return (
    <div className="exam-mode flex flex-col h-screen bg-gray-50">
      {/* ── Top bar ── */}
      <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between shrink-0">
        <div>
          <h1 className="font-bold text-gray-900 text-sm">{exam.title}</h1>
          <p className="text-xs text-gray-400">{exam.subject?.name} · Kelas {exam.classRoom}</p>
        </div>

        <div className="flex items-center gap-6">
          {/* Cheat warning */}
          {cheatCount > 0 && (
            <div className="flex items-center gap-1.5 text-red-600 text-xs font-semibold">
              ⚠️ {cheatCount} pelanggaran terdeteksi
            </div>
          )}

          {/* Progress */}
          <div className="text-sm text-gray-500">
            <span className="font-bold text-blue-600">{answered}</span>/{questions.length} dijawab
          </div>

          {/* Timer */}
          <div className="font-mono text-xl font-bold tabular-nums px-4 py-1.5 rounded-lg"
            style={{ color: timerColor, background: `${timerColor}15` }}>
            {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
          </div>

          <button
            className="btn btn-success btn-sm"
            onClick={() => setShowConfirm(true)}
            disabled={submitting}
          >
            {submitting ? "Mengirim..." : "Kirim Jawaban"}
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* ── Question area ── */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-2xl mx-auto">
            {/* Question header */}
            <div className="flex items-center gap-3 mb-5">
              <span className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-white text-sm"
                style={{ background: "var(--color-primary)" }}>
                {currentIdx + 1}
              </span>
              <div>
                <span className={`badge ${currentQ.type === "MULTIPLE_CHOICE" ? "badge-purple" : "badge-yellow"} text-xs`}>
                  {currentQ.type === "MULTIPLE_CHOICE" ? "Pilihan Ganda" : "Essay"}
                </span>
                <span className="text-xs text-gray-400 ml-2">{currentQ.points} poin</span>
              </div>
            </div>

            {/* Question body */}
            <div className="card mb-5">
              {/* Multimedia */}
              {currentQ.imageUrl && (
                <div className="mb-4 rounded-xl overflow-hidden border border-gray-100">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={currentQ.imageUrl} alt="Gambar soal" className="w-full max-h-64 object-contain bg-gray-50" />
                </div>
              )}
              {currentQ.videoUrl && (
                <div className="mb-4">
                  <iframe src={currentQ.videoUrl} className="w-full aspect-video rounded-xl" allowFullScreen />
                </div>
              )}
              <p className="text-gray-900 leading-relaxed text-base">{currentQ.body}</p>
            </div>

            {/* Answer area */}
            {currentQ.type === "MULTIPLE_CHOICE" && (
              <div className="space-y-3">
                {(["A", "B", "C", "D"] as const).map(opt => {
                  const optKey = `option${opt}` as "optionA";
                  const text = currentQ[optKey];
                  if (!text) return null;
                  const selected = answers[currentQ.id] === opt;
                  return (
                    <button
                      key={opt}
                      onClick={() => handleAnswer(currentQ.id, opt)}
                      className={`w-full text-left flex items-center gap-4 p-4 rounded-xl border-2 transition-all
                        ${selected
                          ? "border-blue-500 bg-blue-50"
                          : "border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50/30"
                        }`}
                    >
                      <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm shrink-0 transition-all
                        ${selected ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-600"}`}>
                        {opt}
                      </span>
                      <span className="text-gray-800">{text}</span>
                    </button>
                  );
                })}
              </div>
            )}

            {currentQ.type === "ESSAY" && (
              <div>
                <label className="label">Jawaban Essay</label>
                <textarea
                  className="input min-h-40 resize-none"
                  placeholder="Tulis jawaban Anda di sini..."
                  value={answers[currentQ.id] || ""}
                  onChange={e => handleAnswer(currentQ.id, e.target.value)}
                />
              </div>
            )}

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8">
              <button
                className="btn btn-outline btn-sm"
                onClick={() => setCurrentIdx(p => Math.max(0, p - 1))}
                disabled={currentIdx === 0}
              >
                ← Sebelumnya
              </button>
              <span className="text-sm text-gray-400">
                {currentIdx + 1} / {questions.length}
              </span>
              <button
                className="btn btn-primary btn-sm"
                onClick={() => setCurrentIdx(p => Math.min(questions.length - 1, p + 1))}
                disabled={currentIdx === questions.length - 1}
              >
                Berikutnya →
              </button>
            </div>
          </div>
        </div>

        {/* ── Question navigator sidebar ── */}
        <div className="w-52 border-l border-gray-200 bg-white p-4 overflow-y-auto shrink-0">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3">Navigasi Soal</p>
          <div className="grid grid-cols-4 gap-1.5">
            {questions.map((q, i) => {
              const isAnswered = !!answers[q.id];
              const isCurrent = i === currentIdx;
              return (
                <button
                  key={q.id}
                  onClick={() => setCurrentIdx(i)}
                  className={`w-full aspect-square rounded-lg text-xs font-bold transition-all
                    ${isCurrent
                      ? "ring-2 ring-blue-500 ring-offset-1 bg-blue-600 text-white"
                      : isAnswered
                        ? "bg-green-100 text-green-700"
                        : "bg-gray-100 text-gray-400 hover:bg-gray-200"
                    }`}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>

          <div className="mt-4 space-y-1.5">
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <div className="w-3 h-3 rounded bg-green-100" />
              Sudah dijawab
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <div className="w-3 h-3 rounded bg-gray-100" />
              Belum dijawab
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <div className="w-3 h-3 rounded bg-blue-600" />
              Soal aktif
            </div>
          </div>
        </div>
      </div>

      {/* ── Confirm submit modal ── */}
      {showConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-sm w-full mx-4 text-center">
            <div className="text-5xl mb-4">📨</div>
            <h3 className="text-xl font-bold mb-2">Kirim Jawaban?</h3>
            <p className="text-gray-500 text-sm mb-2">
              Anda telah menjawab <strong>{answered}</strong> dari <strong>{questions.length}</strong> soal.
            </p>
            {answered < questions.length && (
              <div className="alert alert-warning mb-4 text-sm">
                ⚠️ {questions.length - answered} soal belum dijawab!
              </div>
            )}
            <p className="text-gray-500 text-sm mb-6">Apakah Anda yakin ingin mengirimkan jawaban?</p>
            <div className="flex gap-3">
              <button className="btn btn-ghost flex-1" onClick={() => setShowConfirm(false)}>Batal</button>
              <button className="btn btn-success flex-1" onClick={() => handleSubmit(false)} disabled={submitting}>
                {submitting ? "Mengirim..." : "Kirim"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
