// src/app/student/exam/[attemptId]/result/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function ExamResultPage({ params }: { params: Promise<{ attemptId: string }> }) {
  const { attemptId } = await params;
  const user = await getCurrentUser();

  const attempt = await prisma.examAttempt.findUnique({
    where: { id: Number(attemptId), studentId: user!.userId },
    include: {
      exam: { include: { subject: { select: { name: true } } } },
      cheatLogs: true,
    },
  });

  if (!attempt) redirect("/student/dashboard");

  const passed = (attempt.score || 0) >= 75;
  const cheatCount = attempt.cheatLogs.length;

  return (
    <div className="p-8 max-w-xl mx-auto">
      <div className="text-center mb-8">
        <div className="text-6xl mb-4">{passed ? "🎉" : "📝"}</div>
        <h1 className="text-2xl font-bold text-gray-900">
          {passed ? "Selamat! Anda Lulus" : "Ujian Selesai"}
        </h1>
        <p className="text-gray-500 mt-1">{attempt.exam.title}</p>
      </div>

      {/* Score card */}
      <div className={`rounded-2xl p-8 text-center mb-6 ${passed ? "bg-green-50 border-2 border-green-200" : "bg-red-50 border-2 border-red-200"}`}>
        <div className={`text-6xl font-black mb-2 ${passed ? "text-green-600" : "text-red-600"}`}>
          {attempt.score?.toFixed(1) ?? "–"}
        </div>
        <div className="text-sm text-gray-500">dari nilai maksimal {attempt.maxScore?.toFixed(0)}</div>
        <div className={`mt-3 inline-block badge ${passed ? "badge-green" : "badge-red"} text-sm px-4 py-1.5`}>
          {passed ? "LULUS" : "TIDAK LULUS"}
        </div>
      </div>

      {/* Details */}
      <div className="card mb-6">
        <h2 className="font-bold mb-4">Detail Ujian</h2>
        <div className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">Mata Pelajaran</span>
            <span className="font-medium">{attempt.exam.subject.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Kelas</span>
            <span className="font-medium">{attempt.exam.classRoom}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Waktu Selesai</span>
            <span className="font-medium">
              {attempt.submittedAt ? new Date(attempt.submittedAt).toLocaleString("id-ID") : "–"}
            </span>
          </div>
          {cheatCount > 0 && (
            <div className="flex justify-between text-red-600">
              <span>⚠️ Pelanggaran Terdeteksi</span>
              <span className="font-bold">{cheatCount} kali</span>
            </div>
          )}
        </div>
      </div>

      <Link href="/student/dashboard" className="btn btn-primary w-full">
        Kembali ke Dashboard
      </Link>
    </div>
  );
}
