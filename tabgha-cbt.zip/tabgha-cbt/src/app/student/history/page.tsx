// src/app/student/history/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export default async function StudentHistoryPage() {
  const user = await getCurrentUser();
  const attempts = await prisma.examAttempt.findMany({
    where: { studentId: user!.userId },
    include: {
      exam: { include: { subject: { select: { name: true } } } },
      cheatLogs: { select: { id: true } },
    },
    orderBy: { startedAt: "desc" },
  });

  return (
    <div className="p-8">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Riwayat Ujian</h1>
        <p className="text-gray-500 mt-1">Semua ujian yang pernah Anda ikuti.</p>
      </div>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr><th>#</th><th>Ujian</th><th>Mata Pelajaran</th><th>Kelas</th><th>Nilai</th><th>Status</th><th>Tanggal</th></tr>
          </thead>
          <tbody>
            {attempts.length === 0 && (
              <tr><td colSpan={7} className="text-center text-gray-400 py-10">Belum ada riwayat ujian</td></tr>
            )}
            {attempts.map((a, i) => (
              <tr key={a.id}>
                <td className="text-gray-400 text-xs">{i + 1}</td>
                <td className="font-medium">{a.exam.title}</td>
                <td>{a.exam.subject.name}</td>
                <td>{a.exam.classRoom}</td>
                <td>
                  <span className={`font-bold ${(a.score || 0) >= 75 ? "text-green-600" : a.score !== null ? "text-red-600" : "text-gray-400"}`}>
                    {a.score?.toFixed(1) ?? "–"}
                  </span>
                </td>
                <td>
                  <span className={`badge ${a.isSubmitted ? "badge-green" : "badge-yellow"}`}>
                    {a.isSubmitted ? "Selesai" : "Belum Submit"}
                  </span>
                  {a.cheatLogs.length > 0 && (
                    <span className="badge badge-red ml-1">⚠️ {a.cheatLogs.length}</span>
                  )}
                </td>
                <td className="text-sm text-gray-500">
                  {new Date(a.startedAt).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" })}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
