// src/app/student/dashboard/page.tsx
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import Link from "next/link";

export default async function StudentDashboardPage() {
  const user = await getCurrentUser();
  const studentId = user!.userId;

  const [attempts, setting] = await Promise.all([
    prisma.examAttempt.findMany({
      where: { studentId },
      include: { exam: { select: { title: true, subject: { select: { name: true } } } } },
      orderBy: { startedAt: "desc" },
      take: 5,
    }),
    prisma.systemSetting.findFirst(),
  ]);

  const totalAttempts = await prisma.examAttempt.count({ where: { studentId } });
  const submitted = await prisma.examAttempt.count({ where: { studentId, isSubmitted: true } });
  const avgScore = await prisma.examAttempt.aggregate({
    where: { studentId, isSubmitted: true, score: { not: null } },
    _avg: { score: true },
  });

  const stats = [
    { label: "Total Ujian", value: totalAttempts, icon: "📋", color: "#2563eb" },
    { label: "Sudah Selesai", value: submitted, icon: "✅", color: "#16a34a" },
    { label: "Rata-rata Nilai", value: avgScore._avg.score?.toFixed(1) ?? "–", icon: "⭐", color: "#d97706" },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Halo, {user?.name}! 👋</h1>
        <p className="text-gray-500 mt-1">
          Kelas {user?.classRoom} · {setting?.schoolName} · {setting?.activeTerm}
        </p>
      </div>

      {/* Quick action */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-6 mb-8 text-white">
        <h2 className="text-lg font-bold mb-1">Ikuti Ujian Baru</h2>
        <p className="text-blue-200 text-sm mb-4">Masukkan token yang diberikan guru untuk memulai ujian.</p>
        <Link href="/student/exam" className="btn bg-white text-blue-700 hover:bg-blue-50 font-bold btn-sm">
          Mulai Ujian →
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {stats.map(s => (
          <div key={s.label} className="stat-card">
            <div className="text-2xl">{s.icon}</div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Recent attempts */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold">Riwayat Ujian Terakhir</h2>
          <Link href="/student/history" className="text-sm text-blue-600 hover:underline">Lihat semua →</Link>
        </div>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr><th>Ujian</th><th>Mata Pelajaran</th><th>Nilai</th><th>Status</th></tr>
            </thead>
            <tbody>
              {attempts.length === 0 && (
                <tr><td colSpan={4} className="text-center text-gray-400 py-8">Belum ada riwayat ujian</td></tr>
              )}
              {attempts.map(a => (
                <tr key={a.id}>
                  <td className="font-medium">{a.exam.title}</td>
                  <td>{a.exam.subject.name}</td>
                  <td className={`font-bold ${(a.score || 0) >= 75 ? "text-green-600" : a.score ? "text-red-600" : "text-gray-400"}`}>
                    {a.score?.toFixed(1) ?? "–"}
                  </td>
                  <td>
                    <span className={`badge ${a.isSubmitted ? "badge-green" : "badge-yellow"}`}>
                      {a.isSubmitted ? "Selesai" : "Belum Submit"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
