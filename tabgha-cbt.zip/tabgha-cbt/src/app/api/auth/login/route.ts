// src/app/api/auth/login/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { comparePassword, signToken, setAuthCookie } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const { username, password } = await req.json();

    if (!username || !password) {
      return NextResponse.json({ success: false, error: "Username dan password wajib diisi" }, { status: 400 });
    }

    const user = await prisma.user.findUnique({ where: { username } });
    if (!user) {
      return NextResponse.json({ success: false, error: "Username atau password salah" }, { status: 401 });
    }

    const valid = await comparePassword(password, user.password);
    if (!valid) {
      return NextResponse.json({ success: false, error: "Username atau password salah" }, { status: 401 });
    }

    const token = signToken({
      userId: user.id,
      username: user.username,
      name: user.name,
      role: user.role,
      classRoom: user.classRoom,
    });

    await setAuthCookie(token);

    return NextResponse.json({
      success: true,
      data: {
        user: { id: user.id, name: user.name, role: user.role, username: user.username },
      },
    });
  } catch (err) {
    console.error("[LOGIN]", err);
    return NextResponse.json({ success: false, error: "Server error" }, { status: 500 });
  }
}
