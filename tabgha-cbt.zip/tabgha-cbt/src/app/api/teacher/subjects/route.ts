// src/app/api/teacher/subjects/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  return user?.role === "TEACHER" || user?.role === "ADMIN" ? user : null;
}

export async function GET(req: NextRequest) {
  const user = guard(req);
  if (!user) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const subjects = await prisma.subject.findMany({
    where: { creatorId: user.userId },
    include: { _count: { select: { questions: true, exams: true } } },
  });
  return NextResponse.json({ success: true, data: subjects });
}

export async function POST(req: NextRequest) {
  const user = guard(req);
  if (!user) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { name, code } = await req.json();
  if (!name || !code) return NextResponse.json({ success: false, error: "Nama dan kode wajib diisi" }, { status: 400 });
  try {
    const subject = await prisma.subject.create({ data: { name, code, creatorId: user.userId } });
    return NextResponse.json({ success: true, data: subject });
  } catch {
    return NextResponse.json({ success: false, error: "Kode sudah digunakan" }, { status: 409 });
  }
}
