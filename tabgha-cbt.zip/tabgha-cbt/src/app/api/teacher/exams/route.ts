// src/app/api/teacher/exams/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  return user?.role === "TEACHER" || user?.role === "ADMIN" ? user : null;
}

export async function GET(req: NextRequest) {
  const user = guard(req);
  if (!user) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const exams = await prisma.exam.findMany({
    where: { creatorId: user.userId },
    include: { subject: { select: { id: true, name: true } }, _count: { select: { examQuestions: true, examAttempts: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ success: true, data: exams });
}

export async function POST(req: NextRequest) {
  const user = guard(req);
  if (!user) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  try {
    const { title, subjectId, classRoom, duration } = await req.json();
    const exam = await prisma.exam.create({
      data: { title, subjectId: Number(subjectId), creatorId: user.userId, classRoom, duration: Number(duration) },
      include: { subject: { select: { id: true, name: true } } },
    });
    return NextResponse.json({ success: true, data: { ...exam, createdAt: exam.createdAt.toISOString() } });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ success: false, error: "Gagal membuat ujian" }, { status: 500 });
  }
}
