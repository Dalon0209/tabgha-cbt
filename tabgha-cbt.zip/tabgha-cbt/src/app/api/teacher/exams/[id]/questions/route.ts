// src/app/api/teacher/exams/[id]/questions/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  return user?.role === "TEACHER" || user?.role === "ADMIN" ? user : null;
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const examQuestions = await prisma.examQuestion.findMany({
    where: { examId: Number(id) },
    include: { question: true },
    orderBy: { order: "asc" },
  });
  return NextResponse.json({ success: true, data: examQuestions.map(eq => eq.question) });
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  const { questionIds } = await req.json();
  const examId = Number(id);

  // Delete existing, re-insert
  await prisma.examQuestion.deleteMany({ where: { examId } });

  if (questionIds && questionIds.length > 0) {
    await prisma.examQuestion.createMany({
      data: (questionIds as number[]).map((qId, idx) => ({
        examId, questionId: qId, order: idx,
      })),
    });
  }

  return NextResponse.json({ success: true, data: { count: questionIds?.length || 0 } });
}
