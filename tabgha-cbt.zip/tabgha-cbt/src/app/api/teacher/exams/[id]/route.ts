// src/app/api/teacher/exams/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  return user?.role === "TEACHER" || user?.role === "ADMIN" ? user : null;
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  await prisma.exam.delete({ where: { id: Number(id) } });
  return NextResponse.json({ success: true });
}
