// src/app/api/teacher/exams/[id]/export/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";
import ExcelJS from "exceljs";
import { jsPDF } from "jspdf";
// @ts-expect-error - jspdf-autotable has no types
import autoTable from "jspdf-autotable";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user || (user.role !== "TEACHER" && user.role !== "ADMIN")) {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const { searchParams } = new URL(req.url);
  const format = searchParams.get("format") || "excel";

  const exam = await prisma.exam.findUnique({
    where: { id: Number(id) },
    include: { subject: { select: { name: true } } },
  });
  const attempts = await prisma.examAttempt.findMany({
    where: { examId: Number(id) },
    include: {
      student: { select: { name: true, classRoom: true } },
      cheatLogs: { select: { type: true, timestamp: true } },
    },
    orderBy: { startedAt: "asc" },
  });

  const rows = attempts.map((a, i) => ({
    no: i + 1,
    name: a.student.name,
    class: a.student.classRoom || "",
    score: a.score?.toFixed(1) ?? "–",
    status: a.isSubmitted ? "Selesai" : "Belum Submit",
    cheat: a.cheatLogs.length > 0 ? `${a.cheatLogs.length} pelanggaran` : "Bersih",
  }));

  if (format === "excel") {
    const workbook = new ExcelJS.Workbook();
    const ws = workbook.addWorksheet("Hasil Ujian");

    ws.addRow([`Hasil Ujian: ${exam?.title}`]);
    ws.addRow([`Mata Pelajaran: ${exam?.subject?.name} | Kelas: ${exam?.classRoom}`]);
    ws.addRow([]);

    const headers = ["No", "Nama Siswa", "Kelas", "Nilai", "Status", "Kecurangan"];
    ws.addRow(headers);
    ws.getRow(4).font = { bold: true };
    ws.getRow(4).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF2563EB" } };
    ws.getRow(4).font = { bold: true, color: { argb: "FFFFFFFF" } };

    rows.forEach(r => ws.addRow([r.no, r.name, r.class, r.score, r.status, r.cheat]));

    ws.columns = [
      { width: 5 }, { width: 30 }, { width: 10 }, { width: 10 }, { width: 15 }, { width: 20 },
    ];

    const buffer = await workbook.xlsx.writeBuffer();
    return new NextResponse(buffer, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="hasil-ujian.xlsx"`,
      },
    });
  }

  // PDF
  const doc = new jsPDF();
  doc.setFontSize(14);
  doc.text(`Hasil Ujian: ${exam?.title}`, 14, 20);
  doc.setFontSize(10);
  doc.text(`Mapel: ${exam?.subject?.name} | Kelas: ${exam?.classRoom}`, 14, 28);

  autoTable(doc, {
    startY: 35,
    head: [["No", "Nama Siswa", "Kelas", "Nilai", "Status", "Kecurangan"]],
    body: rows.map(r => [r.no, r.name, r.class, r.score, r.status, r.cheat]),
    styles: { fontSize: 9 },
    headStyles: { fillColor: [37, 99, 235] },
  });

  const pdfBuffer = doc.output("arraybuffer");
  return new NextResponse(pdfBuffer, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="hasil-ujian.pdf"`,
    },
  });
}
