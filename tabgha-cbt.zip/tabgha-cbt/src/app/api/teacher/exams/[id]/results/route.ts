// src/app/api/teacher/exams/[id]/results/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user || (user.role !== "TEACHER" && user.role !== "ADMIN")) {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;

  const attempts = await prisma.examAttempt.findMany({
    where: { examId: Number(id) },
    include: {
      student: { select: { id: true, name: true, classRoom: true } },
      cheatLogs: true,
    },
    orderBy: { startedAt: "asc" },
  });

  return NextResponse.json({
    success: true,
    data: attempts.map(a => ({
      ...a,
      startedAt: a.startedAt.toISOString(),
      submittedAt: a.submittedAt?.toISOString() ?? null,
      cheatLogs: a.cheatLogs.map(c => ({ ...c, timestamp: c.timestamp.toISOString() })),
    })),
  });
}
