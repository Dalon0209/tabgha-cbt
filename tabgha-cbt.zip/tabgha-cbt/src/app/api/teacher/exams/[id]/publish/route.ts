// src/app/api/teacher/exams/[id]/publish/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest, generateExamToken } from "@/lib/auth";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = getUserFromRequest(req);
  if (!user || (user.role !== "TEACHER" && user.role !== "ADMIN")) {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const examId = Number(id);

  // Check it has questions
  const qCount = await prisma.examQuestion.count({ where: { examId } });
  if (qCount === 0) {
    return NextResponse.json({ success: false, error: "Ujian harus memiliki minimal 1 soal sebelum dipublikasikan" }, { status: 400 });
  }

  const token = generateExamToken();
  const exam = await prisma.exam.update({
    where: { id: examId },
    data: { status: "PUBLISHED", token },
  });

  return NextResponse.json({ success: true, data: { token: exam.token, status: exam.status } });
}
