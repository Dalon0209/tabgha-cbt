// src/app/api/teacher/questions/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  return user?.role === "TEACHER" || user?.role === "ADMIN" ? user : null;
}

export async function GET(req: NextRequest) {
  const user = guard(req);
  if (!user) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const subjectId = searchParams.get("subjectId");
  const where = subjectId
    ? { subjectId: Number(subjectId), subject: { creatorId: user.userId } }
    : { subject: { creatorId: user.userId } };
  const questions = await prisma.question.findMany({ where, include: { subject: { select: { id: true, name: true } } }, orderBy: { createdAt: "desc" } });
  return NextResponse.json({ success: true, data: questions });
}

export async function POST(req: NextRequest) {
  const user = guard(req);
  if (!user) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  try {
    const { subjectId, type, body, imageUrl, videoUrl, optionA, optionB, optionC, optionD, correctOpt, points } = await req.json();
    const question = await prisma.question.create({
      data: { subjectId: Number(subjectId), type, body, imageUrl: imageUrl || null, videoUrl: videoUrl || null, optionA: optionA || null, optionB: optionB || null, optionC: optionC || null, optionD: optionD || null, correctOpt: correctOpt || null, points: Number(points) || 1 },
    });
    return NextResponse.json({ success: true, data: question });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ success: false, error: "Gagal membuat soal" }, { status: 500 });
  }
}
