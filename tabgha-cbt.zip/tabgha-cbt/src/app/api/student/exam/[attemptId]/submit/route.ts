// src/app/api/student/exam/[attemptId]/submit/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

export async function POST(req: NextRequest, { params }: { params: Promise<{ attemptId: string }> }) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "STUDENT") {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  const { attemptId } = await params;

  const attempt = await prisma.examAttempt.findUnique({
    where: { id: Number(attemptId), studentId: user.userId },
    include: {
      exam: {
        include: {
          examQuestions: {
            include: { question: true },
          },
        },
      },
    },
  });

  if (!attempt) {
    return NextResponse.json({ success: false, error: "Attempt tidak ditemukan" }, { status: 404 });
  }

  if (attempt.isSubmitted) {
    return NextResponse.json({ success: false, error: "Sudah disubmit" }, { status: 400 });
  }

  // ── Auto-scoring (multiple choice only) ──────────────────────────────────
  const answers = attempt.answers as Record<string, string>;
  let score = 0;
  let maxScore = 0;

  for (const eq of attempt.exam.examQuestions) {
    const q = eq.question;
    maxScore += q.points;

    if (q.type === "MULTIPLE_CHOICE" && q.correctOpt) {
      const studentAnswer = answers[String(q.id)];
      if (studentAnswer === q.correctOpt) {
        score += q.points;
      }
    }
    // Essay: scored manually by teacher (score stays 0 for now)
  }

  // Normalize to 0–100
  const normalizedScore = maxScore > 0 ? (score / maxScore) * 100 : 0;

  const cheatCount = await prisma.cheatLog.count({ where: { attemptId: Number(attemptId) } });

  await prisma.examAttempt.update({
    where: { id: Number(attemptId) },
    data: {
      isSubmitted: true,
      isValid: cheatCount === 0,
      score: normalizedScore,
      maxScore: 100,
      submittedAt: new Date(),
    },
  });

  return NextResponse.json({
    success: true,
    data: { score: normalizedScore, maxScore: 100 },
  });
}
