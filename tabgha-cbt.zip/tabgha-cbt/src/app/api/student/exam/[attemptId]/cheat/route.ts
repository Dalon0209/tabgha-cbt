// src/app/api/student/exam/[attemptId]/cheat/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

const VALID_TYPES = ["TAB_SWITCH", "SCREEN_MINIMIZE", "DESKTOP_CHANGE", "BLUR_FOCUS"];

export async function POST(req: NextRequest, { params }: { params: Promise<{ attemptId: string }> }) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "STUDENT") {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  const { attemptId } = await params;
  const { type } = await req.json();

  if (!VALID_TYPES.includes(type)) {
    return NextResponse.json({ success: false, error: "Invalid cheat type" }, { status: 400 });
  }

  await prisma.cheatLog.create({
    data: { attemptId: Number(attemptId), type },
  });

  return NextResponse.json({ success: true });
}
