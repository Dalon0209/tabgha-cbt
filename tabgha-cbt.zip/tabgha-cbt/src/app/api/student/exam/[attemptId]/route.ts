// src/app/api/student/exam/[attemptId]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest, { params }: { params: Promise<{ attemptId: string }> }) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "STUDENT") {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  const { attemptId } = await params;

  const attempt = await prisma.examAttempt.findUnique({
    where: { id: Number(attemptId), studentId: user.userId },
    include: {
      exam: {
        include: {
          subject: { select: { id: true, name: true } },
          examQuestions: {
            include: {
              question: {
                select: {
                  id: true, type: true, body: true, imageUrl: true, videoUrl: true,
                  optionA: true, optionB: true, optionC: true, optionD: true,
                  points: true,
                  // NEVER expose correctOpt to student
                },
              },
            },
            orderBy: { order: "asc" },
          },
        },
      },
    },
  });

  if (!attempt) {
    return NextResponse.json({ success: false, error: "Ujian tidak ditemukan" }, { status: 404 });
  }

  if (attempt.isSubmitted) {
    return NextResponse.json({ success: false, error: "Ujian sudah selesai" }, { status: 400 });
  }

  return NextResponse.json({
    success: true,
    data: {
      attempt: {
        id: attempt.id,
        answers: attempt.answers,
        startedAt: attempt.startedAt.toISOString(),
        isSubmitted: attempt.isSubmitted,
      },
      exam: {
        id: attempt.exam.id,
        title: attempt.exam.title,
        duration: attempt.exam.duration,
        classRoom: attempt.exam.classRoom,
        subject: attempt.exam.subject,
        questions: attempt.exam.examQuestions.map(eq => eq.question),
      },
    },
  });
}
