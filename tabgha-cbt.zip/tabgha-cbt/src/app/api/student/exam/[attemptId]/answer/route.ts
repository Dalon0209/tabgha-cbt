// src/app/api/student/exam/[attemptId]/answer/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

export async function PUT(req: NextRequest, { params }: { params: Promise<{ attemptId: string }> }) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "STUDENT") {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  const { attemptId } = await params;
  const { answers } = await req.json();

  await prisma.examAttempt.update({
    where: { id: Number(attemptId), studentId: user.userId },
    data: { answers },
  });

  return NextResponse.json({ success: true });
}
