// src/app/api/student/exam/join/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "STUDENT") {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { token } = await req.json();

    const exam = await prisma.exam.findUnique({
      where: { token, status: "PUBLISHED" },
      include: { examQuestions: { select: { questionId: true } } },
    });

    if (!exam) {
      return NextResponse.json({ success: false, error: "Token tidak valid atau ujian belum aktif" }, { status: 404 });
    }

    if (exam.examQuestions.length === 0) {
      return NextResponse.json({ success: false, error: "Ujian belum memiliki soal" }, { status: 400 });
    }

    // Check if already attempted
    const existing = await prisma.examAttempt.findUnique({
      where: { examId_studentId: { examId: exam.id, studentId: user.userId } },
    });

    if (existing) {
      if (existing.isSubmitted) {
        return NextResponse.json({ success: false, error: "Anda sudah menyelesaikan ujian ini" }, { status: 409 });
      }
      // Resume existing attempt
      return NextResponse.json({ success: true, data: { attemptId: existing.id } });
    }

    // Create new attempt
    const attempt = await prisma.examAttempt.create({
      data: {
        examId: exam.id,
        studentId: user.userId,
        answers: {},
        isSubmitted: false,
        isValid: true,
      },
    });

    return NextResponse.json({ success: true, data: { attemptId: attempt.id } });
  } catch (err) {
    console.error("[JOIN EXAM]", err);
    return NextResponse.json({ success: false, error: "Server error" }, { status: 500 });
  }
}
