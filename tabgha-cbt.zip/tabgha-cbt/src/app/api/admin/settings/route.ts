// src/app/api/admin/settings/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "ADMIN") return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const setting = await prisma.systemSetting.findFirst();
  return NextResponse.json({ success: true, data: setting });
}

export async function PUT(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "ADMIN") return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const { schoolName, activeTerm, schoolLevel } = await req.json();
  const setting = await prisma.systemSetting.upsert({
    where: { id: 1 },
    create: { id: 1, schoolName, activeTerm, schoolLevel },
    update: { schoolName, activeTerm, schoolLevel },
  });
  return NextResponse.json({ success: true, data: setting });
}
