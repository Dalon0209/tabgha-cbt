// src/app/api/admin/users/import/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest, hashPassword } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "ADMIN") {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { csv } = await req.json();
    const lines = (csv as string).split("\n").filter(Boolean);
    const rows = lines.slice(1); // skip header

    let imported = 0;
    const errors: string[] = [];

    for (const row of rows) {
      const [username, password, name, role, classRoom] = row.split(",").map(s => s.trim());
      if (!username || !password || !name || !role) continue;
      if (!["ADMIN", "TEACHER", "STUDENT"].includes(role)) {
        errors.push(`${username}: role tidak valid`);
        continue;
      }
      try {
        const hashed = await hashPassword(password);
        await prisma.user.upsert({
          where: { username },
          create: { username, password: hashed, name, role: role as "ADMIN" | "TEACHER" | "STUDENT", classRoom: classRoom || null },
          update: { password: hashed, name, role: role as "ADMIN" | "TEACHER" | "STUDENT", classRoom: classRoom || null },
        });
        imported++;
      } catch {
        errors.push(`${username}: gagal disimpan`);
      }
    }

    return NextResponse.json({ success: true, data: { imported, errors } });
  } catch {
    return NextResponse.json({ success: false, error: "Gagal parsing CSV" }, { status: 400 });
  }
}
