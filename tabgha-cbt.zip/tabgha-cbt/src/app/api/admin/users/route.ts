// src/app/api/admin/users/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest, hashPassword } from "@/lib/auth";

function guard(req: NextRequest) {
  const user = getUserFromRequest(req);
  if (!user || user.role !== "ADMIN") return false;
  return true;
}

export async function GET(req: NextRequest) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });

  const users = await prisma.user.findMany({
    orderBy: [{ role: "asc" }, { name: "asc" }],
    select: { id: true, username: true, name: true, role: true, classRoom: true, createdAt: true },
  });
  return NextResponse.json({ success: true, data: users.map(u => ({ ...u, createdAt: u.createdAt.toISOString() })) });
}

export async function POST(req: NextRequest) {
  if (!guard(req)) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });

  try {
    const { username, password, name, role, classRoom } = await req.json();
    if (!username || !password || !name || !role) {
      return NextResponse.json({ success: false, error: "Field wajib diisi" }, { status: 400 });
    }

    const exists = await prisma.user.findUnique({ where: { username } });
    if (exists) return NextResponse.json({ success: false, error: "Username sudah digunakan" }, { status: 409 });

    const hashed = await hashPassword(password);
    const user = await prisma.user.create({
      data: { username, password: hashed, name, role, classRoom: classRoom || null },
      select: { id: true, username: true, name: true, role: true, classRoom: true, createdAt: true },
    });

    return NextResponse.json({ success: true, data: { ...user, createdAt: user.createdAt.toISOString() } });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ success: false, error: "Server error" }, { status: 500 });
  }
}
